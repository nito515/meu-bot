const slot = (somtoy, somtoy2, somtoy3) => {
return `         
             
    ┠╼╾╼╾╼╾╼╾╼╾╼╾╼╾┤
  
    ╭╼╾╼╾╼╾╼╾╼╾╼╾╼╾╮ 
    ╽           [💰SLOT💰 | 777 ]        
    ┃                                             
    ┃                                             
    ┃            ${somtoy}  ◄━━┛
    ┃            ${somtoy2}  ◄━━┛
    ┃            ${somtoy3}  ◄━━┛
    ┃                                             
    ┃                                             
    ╿           [💰SLOT💰 | 777 ]        
    ╰╼╾╼╾╼╾╼╾╼╾╼╾╼╾╯
                            @ɪᴛᴀʟᴜ
    ┠╼╾╼╾╼╾╼╾╼╾╼╾╼╾┤

`
}

exports.slot = slot
