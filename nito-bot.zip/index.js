 /*Dono: Nito. */
//--API WHATSAPP WEB
const {
  WAConnection,
  MessageType,
  Presence,
  Mimetype,
  GroupSettingChange,
  MessageOptions,
  WALocationMessage,
  WA_MESSAGE_STUB_TYPES,
  ReconnectMode,
  ProxyAgent,
  waChatKey,
  mentionedJid,
  processTime,
  ChatModification,
} = require('@adiwajshing/baileys');
//--

//--ARQUIVOS JS
const {color, bgcolor} = require('./lib/color');
const {bahasa} = require('./src/bahasa');
const {wait, simih, getBuffer, h2k, generateMessageID, getGroupAdmins, getRandom, banner, start, info, success, clos } = require('./lib/functions');
const {fetchJson} = require('./lib/fetcher');
const {recognize} = require('./lib/ocr');
const { slot } = require('./src/slot')
//--

//--ARQUIVOS DO NPM
const fs = require('fs');
const moment = require('moment-timezone');
const {exec} = require('child_process');
const kagApi = require('@kagchi/kag-api');
const fetc = require('node-fetch');
const tiktod = require('tiktok-scraper');
const ffmpeg = require('fluent-ffmpeg');
const {removeBackgroundFromImageFile} = require('remove.bg');
const imgbb = require('imgbb-uploader');
const lolis = require('lolis.life');
const loli = new lolis();
const speed = require('performance-now');
const cd = 4.32e+7 ;
const qrcode = require("qrcode-terminal");
const crypto = require('crypto')
//const { decryptMedia } = require('@open-wa/wa-automate');
//--

//--ARQUIVOS JSON
const nsfw = JSON.parse(fs.readFileSync('./data/nsfw.json'))
const welkom = JSON.parse(fs.readFileSync('./data/welkom.json'));
const up = JSON.parse(fs.readFileSync('./data/settings.json'));
const samih = JSON.parse(fs.readFileSync('./data/simi.json'))
//--

//--ARQUIVOS DE MÍDIA 
const setiker = JSON.parse(fs.readFileSync('./temp/stik.json'))
const videonye = JSON.parse(fs.readFileSync('./temp/vid.json'))
const audionye = JSON.parse(fs.readFileSync('./temp/vn.json'))
const imagenye = JSON.parse(fs.readFileSync('./temp/image.json'))

//--ARQUIVOS DE INFORMAÇÕES DO USUÁRIO 
const _leveling = JSON.parse(fs.readFileSync('./datauser/leveling.json'))
const _level = JSON.parse(fs.readFileSync('./datauser/level.json'))
//const uang = JSON.parse(fs.readFileSync('./datauser/uang.json'))
const _registered = JSON.parse(fs.readFileSync('./datauser/registered.json'));
//--

//--File json data
const trut = JSON.parse(fs.readFileSync('./data/truth.json'));
const fak = JSON.parse(fs.readFileSync('./data/dare.json'));
const dare = JSON.parse(fs.readFileSync('./data/fakta.json'));
//--


//--Setting
prefix = "$"
//const limitawal = up.limit;
const memberlimit = up.memberlimit;
const cr = "Nito-BOT v1.0🧙‍♂️"
const crt = "Sticker criado com sucesso✅"
const hargalimit = up.hargalimit;
const NamaBot = up.NamaBot;
const Ig = up.Ig;
const Wa1 = up.Wa1;
const Wa2 = up.Wa2;
const Ovo = up.Ovo;
const Pulsa = up.Pulsa;
const Dana = up.Dana;
const blocked = [];
const ownerNumber = up.ownerNumber;
const ownerName = up.OwnerName;
//--

//--Apikey
BarBarKey = up.BarBarKey;
vKey = up.Vhtearkey;
viKey = up.Vinzapi
meKey = up.Itsmeikyapi
lolKey = up.LolHumanKey
//--

//--Kontak
const vcard = 'BEGIN:VCARD\n' 
            + 'VERSION:3.0\n' 
            + 'FN:Nito🧙‍♂️\n' 
            + 'ORG:Dono do Nito;\n' 
            + 'TEL;type=CELL;type=VOICE;waid=5519997149535:+55 19 99714-9535\n' 
            + 'END:VCARD'


//--Datauser

/*const getLimit = (sender) => {
  let position = false
  Object.keys(limit).forEach ((i) => {
if (limit[position].id === sender) {
  position = i
}
  })
  if (position !== false) {
return limit[position].limit
  }
}
*/
const getRegisteredRandomId = () => {
  return _registered[Math.floor(Math.random() * _registered.length)].id
}

const addRegisteredUser = (userid, sender, age, time, serials) => {
  const obj = {
id: userid,
name: sender,
age: age,
time: time,
serial: serials
  }
  _registered.push(obj)
  fs.writeFileSync('./datauser/registered.json', JSON.stringify(_registered))
}

const createSerial = (size) => {
  return crypto.randomBytes(size).toString('hex').slice(0, size)
}

const checkRegisteredUser = (sender) => {
  let status = false
  Object.keys(_registered).forEach((i) => {
if (_registered[i].id === sender) {
  status = true
}
  })
  return status
}


/*const addATM = (sender) => {
  const obj = {
id: sender, uang: 0
  }
  uang.push(obj)
  fs.writeFileSync('./datauser/uang.json',
JSON.stringify(uang))
}

const addKoinUser = (sender, amount) => {
  let position = false
  Object.keys(uang).forEach((i) => {
if (uang[i].id === sender) {
  position = i
}
  })
  if (position !== false) {
uang[position].uang += amount
fs.writeFileSync('./datauser/uang.json', JSON.stringify(uang))
  }
}

const checkATMuser = (sender) => {
  let position = false
  Object.keys(uang).forEach((i) => {
if (uang[i].id === sender) {
  position = i
}
  })
  if (position !== false) {
return uang[position].uang
  }
}

const bayarLimit = (sender, amount) => {
  let position = false
  Object.keys(_limit).forEach((i) => {
if (_limit[i].id === sender) {
  position = i
}
  })
  if (position !== false) {
_limit[position].limit -= amount
fs.writeFileSync('./datauser/limit.json', JSON.stringify(_limit))
  }
}

const confirmATM = (sender, amount) => {
  let position = false
  Object.keys(uang).forEach((i) => {
if (uang[i].id === sender) {
  position = i
}
  })
  if (position !== false) {
uang[position].uang -= amount
fs.writeFileSync('./datauser/uang.json', JSON.stringify(uang))
  }
}

const limitAdd = (sender) => {
  let position = false
  Object.keys(_limit).forEach((i) => {
if (_limit[i].id == sender) {
  position = i
}
  })
  if (position !== false) {
_limit[position].limit += 1
fs.writeFileSync('./datauser/limit.json', JSON.stringify(_limit))
  }
}
*/

const getLevelingXp = (sender) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                return _level[position].xp
            }
        }

        const getLevelingLevel = (sender) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                return _level[position].level
            }
        }

        const getLevelingId = (sender) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                return _level[position].id
            }
        }

        const addLevelingXp = (sender, amount) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                _level[position].xp += amount
                fs.writeFileSync('./datauser/level.json', JSON.stringify(_level))
            }
        }

        const addLevelingLevel = (sender, amount) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                _level[position].level += amount
                fs.writeFileSync('./datauser/level.json', JSON.stringify(_level))
            }
        }

        const addLevelingId = (sender) => {
            const obj = {id: sender, xp: 1, level: 1}
            _level.push(obj)
            fs.writeFileSync('./datauser/level.json', JSON.stringify(_level))
        }

        /*const addATM = (sender) => {
        	const obj = {id: sender, uang : 0}
            uang.push(obj)
            fs.writeFileSync('./datauser/uang.json', JSON.stringify(uang))
        }
        
        const addKoinUser = (sender, amount) => {
            let position = false
            Object.keys(uang).forEach((i) => {
                if (uang[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                uang[position].uang += amount
                fs.writeFileSync('./datauser/uang.json', JSON.stringify(uang))
            }
        }
        
        const checkATMuser = (sender) => {
        	let position = false
            Object.keys(uang).forEach((i) => {
                if (uang[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                return uang[position].uang
            }
        }
           	
        const confirmATM = (sender, amount) => {
        	let position = false
            Object.keys(uang).forEach((i) => {
                if (uang[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                uang[position].uang -= amount
                fs.writeFileSync('./datauser/uang.json', JSON.stringify(uang))
            }
        }*/

//--Waktu
function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var second = Math.floor(seconds % 60);
  return `${pad(hours)}:${pad(minutes)}:${pad(second)}`;
}
//--


//--Whatsapp start connect
async function starts() {
	const nito= new WAConnection()
	nito.logger.level = 'warn'
	console.log(banner.string)
	nito.on('qr', () => {
		console.log(color('👆'), color(' Escanear o código acima para iniciar o NITO-BOT!'))
	})

	fs.existsSync('./Nito.json') && nito.loadAuthInfo('./Nito.json')
	nito.on('connecting', () => {
		start('2', 'Connecting...')
	})
	nito.on('open', () => {
		success('2', 'Connected')
	})
	await nito.connect({timeoutMs: 30*1000})
        fs.writeFileSync('./Nito.json', JSON.stringify(nito.base64EncodedAuthInfo(), null, '\t'))


	nito.on('group-participants-update', async (anu) => {
		if (!welkom.includes(anu.jid)) return
		try {
			const mdata = await nito.groupMetadata(anu.jid)
			console.log(anu)
			if (anu.action == 'add') {
				num = anu.participants[0]
				try {
					ppimg = await nito.getProfilePicture(`${anu.participants[0].split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				teks = `Olá @${num.split('@')[0]}\nSeja bem vindo(a) ao grupo: ${mdata.subject}`
				let buff = await getBuffer(ppimg)
				nito.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			} else if (anu.action == 'remove') {
				num = anu.participants[0]
				try {
					ppimg = await nito.getProfilePicture(`${num.split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				teks = `O integrante @${num.split('@')[0]} saiu do grupo... bye bye👋`
				let buff = await getBuffer(ppimg)
				nito.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			}
		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		}
	})

	nito.on('CB:Blocklist', json => {
            if (blocked.length > 2) return
	    for (let i of json[1].blocklist) {
	    	blocked.push(i.replace('c.us','s.whatsapp.net'))
	    }
	})

	nito.on('chat-update', async (mek) => {
		try {
            if (!mek.hasNewMessage) return
            mek = mek.messages.all()[0]
			if (!mek.message) return
			if (mek.key && mek.key.remoteJid == 'status@broadcast') return
			if (mek.key.fromMe) return
			global.prefix
			global.blocked
			const content = JSON.stringify(mek.message)
			const from = mek.key.remoteJid
			const type = Object.keys(mek.message)[0]
			const { text, extendedText, contact, location, liveLocation, image, video, sticker, document, audio, product } = MessageType
			const time = moment.tz('Asia/Jakarta').format('DD/MM HH:mm:ss')
			body = (type === 'conversation' && mek.message.conversation.startsWith(prefix)) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption.startsWith(prefix) ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption.startsWith(prefix) ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text.startsWith(prefix) ? mek.message.extendedTextMessage.text : ''
			budy = (type === 'conversation') ? mek.message.conversation : (type === 'extendedTextMessage') ? mek.message.extendedTextMessage.text : ''
			const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
			const args = body.trim().split(/ +/).slice(1)
			const isCmd = body.startsWith(prefix)
            const is = budy.slice(0).trim().split(/ +/).shift().toLowerCase()

               const sotoy = [
		'🍊 : 🍒 : 🍐',
		'🍒 : 🔔 : 🍊',
		'🍇 : 🍒 : 🍐',
		'🍊 : 🍋 : 🔔',
		'🔔 : 🍒 : 🍐',
		'🔔 : 🍒 : 🍊',
        '🍊 : 🍋 : 🔔',		
		'🍐 : 🍒 : 🍋',
		'🍐 : 🍐 : 🍐',
		'🍊 : 🍒 : 🍒',
		'🔔 : 🔔 : 🍇',
		'🍌 : 🍒 : 🔔',
		'🍐 : 🔔 : 🔔',
		'🍊 : 🍋 : 🍒',
		'🍋 : 🍋 : 🍌',
		'🔔 : 🔔 : 🍇',
		'🔔 : 🍐 : 🍇',
		'🍊 : 🍒 : 🍐',
		'🍒 : 🔔 : 🍊',
		'🍇 : 🍒 : 🍐',
		'🍊 : 🍋 : 🔔',
		'🔔 : 🍒 : 🍐',
		'🔔 : 🍒 : 🍊',
        '🍊 : 🍋 : 🔔',		
		'🍐 : 🍒 : 🍋',
		'🍐 : 🍐 : 🍐',
		'🍊 : 🍒 : 🍒',
		'🔔 : 🔔 : 🍇',
		'🍌 : 🍒 : 🔔',
		'🍐 : 🔔 : 🔔',
		'🍊 : 🍋 : 🍒',
		'🍋 : 🍋 : 🍌',
		'🔔 : 🔔 : 🍇',
		'🔔 : 🍐 : 🍇',
		'🍊 : 🍒 : 🍐',
		'🍒 : 🔔 : 🍊',
		'🍇 : 🍒 : 🍐',
		'🍊 : 🍋 : 🔔',
		'🔔 : 🍒 : 🍐',
		'🔔 : 🍒 : 🍊',
        '🍊 : 🍋 : 🔔',		
		'🍐 : 🍒 : 🍋',
		'🍐 : 🍐 : 🍐',
		'🍊 : 🍒 : 🍒',
		'🔔 : 🔔 : 🍇',
		'🍌 : 🍒 : 🔔',
		'🍐 : 🔔 : 🔔',
		'🍊 : 🍋 : 🍒',
		'🍋 : 🍋 : 🍌',
		'🔔 : 🔔 : 🍇',
		'🔔 : 🍐 : 🍇',
		'🔔 : 🔔 : 🔔',
		'🍒 : 🍒 : 🍒',
		'🍌 : 🍌 : 🍌'
		]
		const sotoy2 = [
		'🍊 : 🍒 : 🍐',
		'🍒 : 🔔 : 🍊',
		'🍇 : 🍒 : 🍐',
		'🍊 : 🍋 : 🔔',
		'🔔 : 🍒 : 🍐',
		'🔔 : 🍒 : 🍊',
        '🍊 : 🍋 : 🔔',		
		'🍐 : 🍒 : 🍋',
		'🍐 : 🍐 : 🍐',
		'🍊 : 🍒 : 🍒',
		'🔔 : 🔔 : 🍇',
		'🍌 : 🍒 : 🔔',
		'🍐 : 🔔 : 🔔',
		'🍊 : 🍋 : 🍒',
		'🍋 : 🍋 : 🍌',
		'🔔 : 🔔 : 🍇',
		'🔔 : 🍐 : 🍇',
		'🍊 : 🍒 : 🍐',
		'🍒 : 🔔 : 🍊',
		'🍇 : 🍒 : 🍐',
		'🍊 : 🍋 : 🔔',
		'🔔 : 🍒 : 🍐',
		'🔔 : 🍒 : 🍊',
        '🍊 : 🍋 : 🔔',		
		'🍐 : 🍒 : 🍋',
		'🍐 : 🍐 : 🍐',
		'🍊 : 🍒 : 🍒',
		'🔔 : 🔔 : 🍇',
		'🍌 : 🍒 : 🔔',
		'🍐 : 🔔 : 🔔',
		'🍊 : 🍋 : 🍒',
		'🍋 : 🍋 : 🍌',
		'🔔 : 🔔 : 🍇',
		'🔔 : 🍐 : 🍇',
		'🍊 : 🍒 : 🍐',
		'🍒 : 🔔 : 🍊',
		'🍇 : 🍒 : 🍐',
		'🍊 : 🍋 : 🔔',
		'🔔 : 🍒 : 🍐',
		'🔔 : 🍒 : 🍊',
        '🍊 : 🍋 : 🔔',		
		'🍐 : 🍒 : 🍋',
		'🍐 : 🍐 : 🍐',
		'🍊 : 🍒 : 🍒',
		'🔔 : 🔔 : 🍇',
		'🍌 : 🍒 : 🔔',
		'🍐 : 🔔 : 🔔',
		'🍊 : 🍋 : 🍒',
		'🍋 : 🍋 : 🍌',
		'🔔 : 🔔 : 🍇',
		'🔔 : 🍐 : 🍇',
		'🔔 : 🔔 : 🔔',
		'🍒 : 🍒 : 🍒',
		'🍌 : 🍌 : 🍌'
		]
		const sotoy3 = [
		'🍊 : 🍒 : 🍐',
		'🍒 : 🔔 : 🍊',
		'🍇 : 🍒 : 🍐',
		'🍊 : 🍋 : 🔔',
		'🔔 : 🍒 : 🍐',
		'🔔 : 🍒 : 🍊',
        '🍊 : 🍋 : 🔔',		
		'🍐 : 🍒 : 🍋',
		'🍐 : 🍐 : 🍐',
		'🍊 : 🍒 : 🍒',
		'🍋 : 🔔 : 🍇',
		'🍌 : 🍒 : 🔔',
		'🍐 : 🔔 : 🔔',
		'🍊 : 🍋 : 🍒',
		'🍋 : 🍋 : 🍌',
		'🔔 : 🔔 : 🍇',
		'🔔 : 🍐 : 🍇',
		'🍊 : 🍒 : 🍐',
		'🍒 : 🔔 : 🍊',
		'🍇 : 🍒 : 🍐',
		'🍊 : 🍋 : 🔔',
		'🔔 : 🍒 : 🍐',
		'🔔 : 🍒 : 🍊',
        '🍊 : 🍋 : 🔔',		
		'🍐 : 🍒 : 🍋',
		'🍐 : 🍐 : 🍐',
		'🍊 : 🍒 : 🍒',
		'🔔 : 🔔 : 🍇',
		'🍌 : 🍒 : 🔔',
		'🍐 : 🔔 : 🔔',
		'🍊 : 🍋 : 🍒',
		'🍋 : 🍋 : 🍌',
		'🔔 : 🔔 : 🍇',
		'🔔 : 🍐 : 🍇',
		'🍊 : 🍒 : 🍐',
		'🍒 : 🔔 : 🍊',
		'🍇 : 🍒 : 🍐',
		'🍊 : 🍋 : 🔔',
		'🔔 : 🍒 : 🍐',
		'🔔 : 🍒 : 🍊',
        '🍊 : 🍋 : 🔔',		
		'🍐 : 🍒 : 🍋',
		'🍐 : 🍐 : 🍐',
		'🍊 : 🍒 : 🍒',
		'🔔 : 🔔 : 🍇',
		'🍌 : 🍒 : 🔔',
		'🍐 : 🔔 : 🔔',
		'🍊 : ?? : 🍒',
		'🍋 : 🍋 : 🍌',
		'🔔 : 🔔 : 🍇',
		'🍐 : 🍐 : 🍇',
		'🔔 : 🔔 : 🔔',
		'🍒 : 🍒 : 🍒',
		'🍌 : 🍌 : 🍌'
		]


			mess = {
  wait: `⏳Aguarde um pouquinho...⏳\n\nCaso não funcione, use o comando novamente.`,
  tterro: `Você deve digitar ${prefix}ppt ✊pedra, 🤚papel ou ✌tesoura`,
  waitmusic: `⏳Aguarde um pouquinho...⏳\n\nA sua música será enviada em até 2 minutos\nCaso não envie, tente especificar o nome da música.`,
  waitfig: `⏳Aguarde um pouquinho...⏳\n\nA criação de stickers demora alguns segundos.`,
  waitgif: `⏳Aguarde um pouquinho...⏳\n\nA criação de stickers demora alguns segundos\nA criação de stickergif leva de 10 segundos á 1 minuto dependendo do tamanho do gif\nLimite de 10 segundos por gif.`,
  waitsfw: `⏳Aguarde um pouquinho...⏳\n\nO bot irá enviar o hentai em até 2 minutos\nTente novamente caso não envie.`,
  waitpor: `⏳Aguarde um pouquinho...⏳\n\nO bot irá enviar a img\nTente novamente caso não envie.`,
  waitimg: `⏳Aguarde um pouquinho...⏳\n\nO bot irá criar e enviar a imagem em alguns instantes.`,
  success: '✅Sucesso✅',
  Public: `O comando só pode ser usado pelo ${ownerName}🕴`,
  ferr: 'Parece que há um problema com o recurso, contate meu dono',
  limitend: 'Desculpe, seu limite acabou, por favor, faça uma compra repetida.',
  error: {
  stick: 'Por favor, tente novamente mais tarde',
  Iv: 'Link inválido'
  },
  only: {
    group: '❌O comando só pode ser usado em grupos❌',
    ownerG: '❌O comando só pode ser usado pelo dono do grupo❌',
    ownerB: `O comando só pode ser usado pelo ${ownerName}🕴`,
    admin: '❌O comando só pode ser usado por administradores do grupo❌' ,
	Badmin: '❌O comando só pode ser usado quando o bot é um administrador do grupo❌' ,
    daftarB: `Olá, digite ${prefix}registrar para começar a usar o bot`
  }
}
            const totalchat = await nito.chats.all()
			const botNumber = nito.user.jid
			const ownerNumber = [`5519997149535@s.whatsapp.net`]
			const isGroup = from.endsWith('@g.us')
			const sender = isGroup ? mek.participant : mek.key.remoteJid
			const groupMetadata = isGroup ? await nito.groupMetadata(from) : ''
			const groupName = isGroup ? groupMetadata.subject : ''
			const groupId = isGroup ? groupMetadata.jid : ''
			const groupMembers = isGroup ? groupMetadata.participants : ''
			const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
			const isBotGroupAdmins = groupAdmins.includes(botNumber) || true
			const isGroupAdmins = groupAdmins.includes(sender) || true
			const isWelkom = isGroup ? welkom.includes(from) : true
            const isNsfw = isGroup ? nsfw.includes(from) : true
			const isOwner = ownerNumber.includes(sender)
            const isRegister = checkRegisteredUser(sender)
            const isSimi = isGroup ? samih.includes(from) : false
            const isLevelingOn = isGroup ? _leveling.includes(from) : true
            nito.chatRead(from)
            const q = args.join(' ')
            const tescuk = ["0@s.whatsapp.net"]
			let pushname = nito.contacts[sender] != undefined ? nito.contacts[sender].vname || ntio.contacts[sender].notify: undefined
			
            //--Balasan bot
            const isUrl = (url) => {
			    return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
			}
			const reply = (teks) => {
				nito.sendMessage(from, teks, text, {quoted:mek})
			}
			const sendMess = (hehe, teks) => {
				nito.sendMessage(hehe, teks, text)
			}
            const sendImage = (teks) => {
		        nito.sendMessage(from, teks, image, {quoted:mek})
            }
			const mentions = (teks, memberr, id) => {
				(id == null || id == undefined || id == false) ? nito.sendMessage(from, teks.trim(), extendedText, {contextInfo: {"mentionedJid": memberr}}) : nito.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": memberr}})
			}
			const costum = (pesan, tipe, target, target2) => {
      nito.sendMessage(from, pesan, tipe, {quoted: {key: {fromMe: false, participant: `${target}`, ...(from ? {
  remoteJid: from
}: {})
  }, message: {
conversation: `${target2}`
  }}})
}
const sendPtt = (teks) => {
  nito.sendMessage(from, audio, mp3, {
quoted: mek
  })
}
            
            const levelRole = getLevelingLevel(sender)
        var role = 'Bronze I🥉'
        if (levelRole === 1) {
            role = 'Bronze  I🥉'
        } else if (levelRole === 2) {
            role = 'Bronze II🥉'
        } else if (levelRole === 3) {
            role = 'Bronze  III🥉'
        } else if (levelRole === 4) {
            role = 'Bronze  IV🥉'
        } else if (levelRole === 5) {
            role = 'Bronze  V🥉'
        } else if (levelRole === 6) {
            role = 'Prata I🥈'
        } else if (levelRole === 7) {
            role = 'Prata II🥈'
        } else if (levelRole === 8) {
            role = 'Prata III🥈'
        } else if (levelRole === 9) {
            role = 'Prata IV🥈'
        } else if (levelRole === 10) {
            role = 'Prata V🥈'
        } else if (levelRole === 11) {
            role = 'Ouro I🥇'
        } else if (levelRole === 12) {
            role = 'Ouro II🥇'
        } else if (levelRole === 13) {
            role = 'Ouro III🥇'
        } else if (levelRole === 14) {
            role = 'Ouro IV🥇'
        } else if (levelRole === 15) {
            role = 'Ouro V🥇'
        } else if (levelRole === 16) {
            role = 'Campeão I🏆'
        } else if (levelRole === 17) {
            role = 'Campeão II🏆'
        } else if (levelRole === 18) {
            role = 'Campeão III🏆'
        } else if (levelRole === 19) {
            role = 'Campeão IV🏆'
        } else if (levelRole === 20) {
            role = 'Campeão V🏆'
        } else if (levelRole === 21) {
            role = 'Diamante I 💎'
        } else if (levelRole === 22) {
            role = 'Diamante II 💎'
        } else if (levelRole === 23) {
            role = 'Diamante III 💎'
        } else if (levelRole === 24) {
            role = 'Diamante IV 💎'
        } else if (levelRole === 25) {
            role = 'Diamante V 💎'
        } else if (levelRole === 26) {
            role = 'Mestre I 🐂'
        } else if (levelRole === 27) {
            role = 'Mestre II 🐂'
        } else if (levelRole === 28) {
            role = 'Mestre III 🐂'
        } else if (levelRole === 29) {
            role = 'Mestre IV 🐂'
        } else if (levelRole === 30) {
            role = 'Mestre V 🐂'
        } else if (levelRole === 31) {
            role = 'Mítico I 🔮'
        } else if (levelRole === 32) {
            role = 'Mítico II 🔮'
        } else if (levelRole === 33) {
            role = 'Mítico III 🔮'
        } else if (levelRole === 34) {
            role = 'Mítico IV 🔮'
        } else if (levelRole === 35) {
            role = 'Mítico V 🔮'
        } else if (levelRole === 36) {
            role = 'God I🕴'
        } else if (levelRole === 37) {
            role = 'God II🕴'
        } else if (levelRole === 38) {
            role = 'God III🕴'
        } else if (levelRole === 39) {
            role = 'God IV🕴'
        } else if (levelRole === 40) {
            role = 'God V🕴'
        } else if (levelRole > 41) {
            role = '🛐Grande Mestre🛐'
        }


            //function leveling
            if (isGroup && isRegister && isLevelingOn) {
            const currentLevel = getLevelingLevel(sender)
            const checkId = getLevelingId(sender)
            try {
                if (currentLevel === undefined && checkId === undefined) addLevelingId(sender)
                const amountXp = Math.floor(Math.random() * 10) + 500
                const requiredXp = 2500 * (Math.pow(2, currentLevel) - 1)
                const getLevel = getLevelingLevel(sender)
                addLevelingXp(sender, amountXp)
                if (requiredXp <= getLevelingXp(sender)) {
                    addLevelingLevel(sender, 1)
                    bayarLimit(sender, 3)
lvup =
` ┏━━━「 LEVEL UP 」━━━┓
     ‣ Nome: @${sender.split("@")[0]}
   ┠─────────────⊱
     ‣ XP: ${getLevelingXp(sender)}
   ┠─────────────⊱
     ‣ Level: ${getLevel} -> ${getLevelingLevel(sender)}
   ┠─────────────⊱
     ‣ Patente: ${role}
  ┗━━━「 LEVEL UP 」━━━┛`
                    reply(lvup)
                }
            } catch (err) {
                console.error(err)
            }
        }

           //function balance
          /*  if (isRegister ) {
            const checkATM = checkATMuser(sender)
            try {
                if (checkATM === undefined) addATM(sender)
                const uangsaku = Math.floor(Math.random() * 10) + 90
                addKoinUser(sender, uangsaku)
            } catch (err) {
                console.error(err)
            }
        }*/



			
//--MessageType
const isMedia = (type === 'imageMessage' || type === 'videoMessage')
const isQuotedText = type === 'extendedTextMessage' && content.includes('textMessage')
const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')

//--Colors
      colors = ['red','white','black','blue','yellow','green','aqua','magenta','orange']

//--Console log grupo
			//if (!isGroup && isCmd) console.log('\x1b[1;37m>', time, color(command), 'de', color(pushname), 'args :', (args.length))
			
//--Console log chat privado
			//if (isCmd && isGroup) console.log('\x1b[1;37m>', time, color(command), 'de', (groupName), 'args :', color(args.length))

//--comandos 
            if (!isGroup && isCmd) console.log(color('COMANDO RECEBIDO', 'magenta'), color('HORA:', 'orange'), color(moment.tz('America/Sao_Paulo').format('HH:mm:ss'), 'yellow'), color('COMANDO:'), color(`${command}`),'DE:', color(pushname))
		    if (isCmd && isGroup) console.log(color('COMANDO RECEBIDO', 'magenta'), color('HORA:', 'orange'), color(moment.tz('America/Sao_Paulo').format('HH:mm:ss'), 'yellow'), color('COMANDO:'), color(`${command}`),'DE:', color(pushname),'EM:', color(groupName))
			
//--Mensagens
            if (!isCmd && isGroup) console.log(color('MENSAGEM RECEBIDA', 'aqua'), color('HORA:', 'orange'), color(moment.tz('America/Sao_Paulo').format('HH:mm:ss'), 'yellow'), 'DE:', color(pushname),'EM:', color(groupName))
			if (!isGroup && !isCmd) console.log(color('MENSAGEM RECEBIDA', 'aqua'), color('HORA:', 'orange'), color(moment.tz('America/Sao_Paulo').format('HH:mm:ss'), 'yellow'), 'DE:', color(pushname))

            authorname = nito.contacts[from] != undefined ? nito.contacts[from].vname || nito.contacts[from].notify : undefined	
			if (authorname != undefined) { } else { authorname = groupName }	

//---Metadata stiker
			function addMetadata(packname, author) {	
				if (!packname) packname = 'WABot'; if (!author) author = 'Bot';	
				author = author.replace(/[^a-zA-Z0-9]/g, '');	
				let name = `${author}_${packname}`
				if (fs.existsSync(`./src/stickers/${name}.exif`)) return `./src/stickers/${name}.exif`
				const json = {	
					"sticker-pack-name": packname,
					"sticker-pack-publisher": author,
				}
				const littleEndian = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00])	
				const bytes = [0x00, 0x00, 0x16, 0x00, 0x00, 0x00]	

				let len = JSON.stringify(json).length	
				let last	

				if (len > 256) {	
					len = len - 256	
					bytes.unshift(0x01)	
				} else {	
					bytes.unshift(0x00)	
				}	

				if (len < 16) {	
					last = len.toString(16)	
					last = "0" + len	
				} else {	
					last = len.toString(16)	
				}	

				const buf2 = Buffer.from(last, "hex")	
				const buf3 = Buffer.from(bytes)	
				const buf4 = Buffer.from(JSON.stringify(json))	

				const buffer = Buffer.concat([littleEndian, buf2, buf3, buf4])	

				fs.writeFile(`./src/stickers/${name}.exif`, buffer, (err) => {	
					return `./src/stickers/${name}.exif`	
				})	

			}

//--Member limit
if (isGroup) {
  try {
const getmemex = groupMembers.length
if (getmemex <= memberlimit) {
  nito.sendMessage(from, `Maaf syarat member harus di atas ${memberlimit}, selamat tinggal 👋🏻`, text)

  setTimeout(() => {
nito.groupLeave(from) // ur cods
  }, 5000) // 1000 = 1s,
}
  } catch {
console.error(err)
  }
}


//--Other Function
const apakah = ['Ya',
  'Tidak',
  'Mungkin']
const bisakah = ['Bisa',
  'Tidak Bisa',
  'Mungkin']
const kapankah = ['Hari Lagi',
  'Minggu Lagi',
  'Bulan Lagi',
  'Tahun Lagi']



//--Auto respon
if(budy.match('nito')){
result = fs.readFileSync(`./temp/stick/emm.webp`)
  nito.sendMessage(from, result, sticker, {
quoted: mek
  })
}

//--End auto respon 1

//--Auto respon 2
switch(is) {
case 'bot':
case 'BOT':
case 'Bot':
buf = fs.readFileSync(`./temp/audio/onichan.mp3`)
nito.sendMessage(from, buf, audio, {
  mimetype: 'audio/mp4', quoted: mek, ptt: true
})
break

case 'dança':
buf = fs.readFileSync(`./teste/nito.webp`)
nito.sendMessage(from, buf, sticker, {quoted: mek})
break

case '.menu':
case '*menu':
case '#menu':
case '#help':
case '!help':
case '!menu':
case '/menu':
case '/help':
case 'help':
case 'menu':
hasil = `        ────────────────
oi ${pushname} use ${prefix}menu caso queira usar meus comandos🧙‍♂️
        ────────────────`
reply(hasil)
        break
}

/*text: `@${sender.split("@")[0]} 🧙‍♂️`,
  contextInfo: {mentionedJid: [sender]
me = nito.user
nito.sendMessage(from, buffer, image, {caption: teks, contextInfo: {mentionedJid: [me.jid]}})
*/
			switch(command) {
case 'help':
  case 'menu':
case '?':
  if (!isRegister) return reply(mess.only.daftarB)
  uptime = process.uptime()
  const Menu = {
text:
 `       ──✪🕴 ∴₰Ⱦꪋℓo፝֯֟ ߷  🕴✪───
        ────────────────
         Olá @${sender.split("@")[0]} 🧙‍♂️
        ────────────────͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏
        ────────────────
🧙‍♂️ BOT 🧙‍♂️
➸ Prefix:「 ${prefix} 」
➸ Nome: Nito-BROTA FIOOO
➸ Versão 10.0
➸ Tempo online: ${kyun(uptime)}
➸ Status: ON✅
➸ Grupo:  ${groupName}
➸ Total de usuários: ${_registered.length} usuários
➸ Total de chats: ${totalchat.length} chats
➸ Total de comandos: 88
      ────♻️NOVIDADES♻️────
    ✅  COMANDOS NOVOS:

      ‣ bneon
      ‣ matrix
      ‣ breakwall
      ‣ dropwater
      ‣ wolflogo
      ‣ tfire
      ‣ sandw
      ‣ firofiro
      ‣ text3d2
      ‣ text3d
      ‣ phlogo
      ‣ bpink
      ‣ folhas
      ‣ tlight
      ‣ shitpost

      ✔ REMOVIDOS:     
       ‣ o comando DDD foi removido

      ⚠️AVISO:
      Os comandos abaixo estão off temporariamente
      ‣ gaming
      ‣ yuri
      ─────────────────
╭════════════•›
┃──🧙‍♂️ Nito-BOT 🧙‍♂️──
┃────────────⊱
┠⊱ ${prefix}info
┃ _Informações do bot_
┠⊱ ${prefix}criador
┃ _Informações do meu criador_
┠⊱ ${prefix}ping
┃ _Mostra meu tempo de resposta_
╰────────────⊱
┏────────────⊱
┃  ── 🔰 MENUS 🔰 ──
┗────────────⊱
╭════•›👥 GRUPO 👥
┠⊱ ${prefix}listadmin
┃ _Lista todos os administradores do grupo_
┠⊱ ${prefix}online
┃ _Lista todos os membros online_
┠⊱ ${prefix}fecharg
┃ _Fecha o grupo_
┠⊱ ${prefix}abrirg
┃ _Abre o grupo_
┠⊱ ${prefix}promover
┃ _Promove o alvo ao cargo de administrador_
┠⊱ ${prefix}rebaixar
┃ _Rabaixa o alvo a membro comum_
┠⊱ ${prefix}setname
┃ _Altera o nome do grupo_
┠⊱ ${prefix}setdesk
┃ _Altera a descrição do grupo_
┠⊱ ${prefix}tagall
┃ _Tag All members_
┠⊱ ${prefix}linkgc
┃ _Link do grupo_
┠⊱ ${prefix}Leave
┃ _O bot sai do grupo_
┠⊱ ${prefix}notif
┃ _Notifica todos os membros_
┠⊱ ${prefix}qelcome
┃ _On/off welcome_
┠⊱ ${prefix}delete (marque a mensagem)
┃ _Apaga uma mensagem enviada pelo bot_
╰────────────⊱
╭════•›🎲 DIVERSÃO 🎲
┠⊱ ${prefix}nomeninja (texto)
┃ _Cria um nome ninja_
┠⊱ ${prefix}infome
┃ _Mostra seu perfil_
┠⊱ ${prefix}tagme
┃ _Te menciona_
┠⊱ ${prefix}conta
┃_Cria uma conta matemática simples_
┠⊱ ${prefix}dado
┃_Sticker de dado aleatório_
┠⊱ ${prefix}ppt (✊pedra, 🤚papel ou ✌tesoura)
┃_Jogue pedra, papel e tesoura com o bot_
┠⊱ ${prefix}sn
┃_Lhe diz sim ou não para uma pergunta_
┠⊱ ${prefix}gado
┃_Lhe diz seu nível de gado_
┠⊱ ${prefix}chance
┃_Lhe diz a chance de algo_
┠⊱ ${prefix}pau
┃_Lhe diz o tamanho do seu brinquedinho_
┠⊱ ${prefix}gay
┃_Lhe diz o quanto gay você é_
┠⊱ ${prefix}slot
┃_Caça níqueis sem premiação algumakkk_
┠⊱ ${prefix}caracoroa
┃_Caracoroa_
╰────────────⊱
╭════•›🎥  MÍDIA 🎥
┠⊱ ${prefix}listvn
┃ _Lista todos os áudios salvos_
┠⊱ ${prefix}listimg
┃ _Lista todas as imagens salvas_
┠⊱ ${prefix}liststik
┃ _Lista todos os stickers salvos_
┠⊱ ${prefix}listvid
┃ _Lista todos os vídeos salvos_
┠⊱ ${prefix}esquilo (marque um áudio)
┃ _Efeito de áudio esquilo_
┠⊱ ${prefix}slow (marque um áudio)
┃ _Efeito de áudio lento_
┠⊱ ${prefix}gemuk (marque um áudio)
┃ _Efeito de áudio gigante_
┠⊱ ${prefix}bass (marque um áudio)
┃ _Aumenta o bass de uma música_
╰────────────⊱
╭════•›🏖 IMAGEM 🏖
┠⊱ ${prefix}gtav (Foto)
┃ _Cria um banner do GTA V_
┠⊱ ${prefix}wanted (Foto)
┃ _Cria um banner estilo "WANTED"_
┠⊱ ${prefix}drawing (Foto)
┃ _Cria uma imagem estilo desenho_
┠⊱ ${prefix}Img (Texto)
┃ _Busca uma imagem relacionada_
┠⊱ ${prefix}8bit (Texto)
┃ _Cria uma imagem no estilo 8bit_
┠⊱ ${prefix}lovepaper (Texto)
┃ _Cria uma imagem no estilo lovepaper_
┠⊱ ${prefix}narutobanner (Texto)
┃ _Cria um banner de Naruto_
┠⊱ ${prefix}romancetext (Texto)
┃ _Cria uma imagem no estilo romancetext_
┠⊱ ${prefix}shadowtext (Texto)
┃ _Cria uma imagem no estilo shadowtext_
┠⊱ ${prefix}tiktokeffect (Texto)
┃ _Cria uma imagem no estilo Tik Tok_
┠⊱ ${prefix}neon (Texto)
┃ _Cria uma imagem no estilo neon_
┠⊱ ${prefix}hpotter
┃ _Cria uma imagem no estilo Harry Potter_
┠⊱ ${prefix}gaming
┃ _Cria uma imagem no estilo gaming_
┠⊱ ${prefix}bneon
┃ _Cria uma imagem no estilo neon_
┠⊱ ${prefix}matrix
┃ _Cria uma imagem no estilo Matrix_
┠⊱ ${prefix}breakwall
┃ _Cria uma imagem no estilo breakwall_
┠⊱ ${prefix}dropwater
┃ _Cria uma imagem no estilo dropwater_
┠⊱ ${prefix}wolflogo
┃ _Cria uma imagem no estilo wolflogo_
┠⊱ ${prefix}tfire
┃ _Cria uma imagem no estilo tfire_
┠⊱ ${prefix}sandw
┃ _Cria uma imagem no estilo sandw_
┠⊱ ${prefix}firofiro
┃ _Cria uma imagem no estilo free fire_
┠⊱ ${prefix}text3d
┃ _Cria uma imagem no estilo text3d_
┠⊱ ${prefix}text3d2
┃ _Cria uma imagem no estilo text3d2_
┠⊱ ${prefix}phlogo
┃ _Cria uma imagem no estilo PornHub_
┠⊱ ${prefix}bpink
┃ _Cria uma imagem no estilo BlackPink_
┠⊱ ${prefix}folhas
┃ _Cria uma imagem com texto entre folhas_
┠⊱ ${prefix}tlight
┃ _Cria uma imagem no estilo tlight_
╰────────────⊱
╭════•›💮 ANIME 💮
┠⊱ ${prefix}anime
┃ _Imagem de anime aleatória_
┠⊱ ${prefix}loli
┃ _Imagem de loli aleatória_
┠⊱ ${prefix}neko
┃ _Imagem de neko aleatória_
╰────────────⊱
╭════•›🔧 FERRAMENTAS 🔧
┠⊱ ${prefix}st
┃ _Cria um sticker em 512x512_
┠⊱ ${prefix}sticker
┃ _Cria um sticker_
┠⊱ ${prefix}triggered
┃ _Cria um sticker no estilo triggered_
┠⊱ ${prefix}wasted
┃ _Cria um sticker no estilo wasted_
┠⊱ ${prefix}toimg
┃ _Converte sticker em imagem_
┠⊱ ${prefix}tomp3
┃ _Converte vídeo em áudio_
┠⊱ ${prefix}play (texto)
┃ _Baixa o áudio de um vídeo no YouTube_
┠⊱ ${prefix}tts (língua) (texto)
┃ _Texto para áudio(voz do google)_
┠⊱ ${prefix}timer (tempo)
┃ _Um timer_
┠⊱ ${prefix}wame
┃ _Mostra seu link wa.me_
┠⊱ ${prefix}ocr
┃ _Captura o texto de uma imagem_
┠⊱ ${prefix}cep (cep)
┃ _Lista algumas informações do cep_
┠⊱ ${prefix}cartão 
┃ _Gera uma cartão de crédito fake_
╰────────────⊱
╭════•›🕹 OUTROS 🕹
┠⊱ ${prefix}shitpost
┃ _Imagem aleatória shitpost br_
╰────────────⊱
╭════•›📲 DOWNLOADER 📲
┠⊱ ${prefix}ytmp3 (Link)
┃ _Baixa audio do youtube_
┠⊱ ${prefix}ytmp4 (Link)
┃ _Baixa video do youtube_
╰────────────⊱
╭════•›🕴 CRIADOR 🕴
┠⊱ ${prefix}clone
┃ _Copia a foto de perfil do alvo_
┠⊱ ${prefix}block
┃ _Bloqueia o alvo_
┠⊱ ${prefix}unblock
┃ _Remove o block do alvo_
┠⊱ ${prefix}blocklist
┃ _Lista dos usuários bloqueados_
╰────────────⊱`,
contextInfo: {mentionedJid: [sender]}}
  costum(Menu, text, tescuk, cr)
  break

case 'level':
           if (!isLevelingOn) return reply(mess.levelnoton)
                if (!isGroup) return reply(mess.only.group)
             const xexpe = getLevelingXp(sender)
             const leveu = getLevel(sender)
levela =
`     ┏━━「 LEVEL 」━━┓
       ‣ Nome: @${sender.split("@")[0]}
      ┠──────────⊱
       ‣ XP: ${xexpe}
      ┠──────────⊱
       ‣ Level: ${leveu}
      ┠──────────⊱
       ‣ Patente: ${role}
      ┗━━「 LEVEL 」━━┛`     
					nito.sendMessage(from, levela, text, {quoted: mek, contextInfo: {mentionedJid: [sender]}})
					break

                    case 'leaderboard':
				case 'lb':
				_level.sort((a, b) => (a.xp < b.xp) ? 1 : -1)
				uang.sort((a, b) => (a.uang < b.uang) ? 1 : -1)
                let leaderboardlvl = '-----[ *LEADERBOARD LEVEL* ]----\n\n'
                let leaderboarduang = '-----[ *LEADERBOARD UANG* ]----\n\n'
                let nom = 0
                try {
                    for (let i = 0; i < 10; i++) {
                        nom++
                        leaderboardlvl += `*[${nom}]* wa.me/${_level[i].id.replace('@s.whatsapp.net', '')}\n┗⊱ *XP*: ${_level[i].xp} *Level*: ${_level[i].level}\n`
                        leaderboarduang += `*[${nom}]* wa.me/${uang[i].id.replace('@s.whatsapp.net', '')}\n┣⊱ *Uang*: _Rp${uang[i].uang}_\n┗⊱ *Limit*: ${limitawal - _limit[i].limit}\n`
                    }
                    await reply(leaderboardlvl)
                    await reply(leaderboarduang)
                } catch (err) {
                    console.error(err)
                    await reply(`minimal 10 user untuk bisa mengakses database`)
                }
				break

case 'infome':
case 'perfil':
  if (!isRegister) return reply(mess.only.daftarB)
  try {
ppimg = await nito.getProfilePicture(`${sender.split('@')[0]}@c.us`)
  } catch {
ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
  }
 const pf = 
`
  ‣ Nome: ${pushname}

  ‣ Número: @${sender.split("@")[0]}

  ‣ Link: wa.me/${sender.split("@")[0]}

  ‣ Registrado: ✅

  ‣ Dinheiro: (em manutenção)
`
  its = await getBuffer (ppimg)
  nito.sendMessage(from, its, image, {quoted: mek, caption: pf, contextInfo: {mentionedJid: [sender]}})
  break
 case 'chats':
const {chats, cursor} = await nito.loadChats (25)
if (cursor) {
    const moreChats = await nito.loadChats (25, cursor) 
}
reply(moreChats)
case 'mining':
                      if (!isRegistered) return reply(ind.noregis())
                      if (isLimit(sender)) return reply(ind.limitend(pushname))
                      if (!isEventon) return reply(`maaf ${pushname} event mining tidak di aktifkan oleh owner`)
                      if (isOwner) {
                      const one = 999999999
                      addLevelingXp(sender, one)
                      addLevelingLevel(sender, 99)
                      reply(`karena anda owner kami dari team bot mengirim ${one}Xp untuk anda`)
                      }else{
                      const mining = Math.ceil(Math.random() * 10000)
                      addLevelingXp(sender, mining)
                      await reply(`*selamat* ${pushname} kamu mendapatkan *${mining}Xp*`)
                      }
                    await limitAdd(sender)
					break    

              case 'setreply':
					if (!isOwner) return reply(ind.ownerb())
                    nito.updatePresence(from, Presence.composing) 
					if (args.length < 1) return
					cr = body.slice(10)
					reply(`reply berhasil di ubah menjadi : ${cr}`)
					await limitAdd(sender)
					break 

case 'disknegão':
                case 'disknegao':
                     reply('http://wa.me/+5574999510904')
                     break
              case 'owner':
case 'criador':
if (!isRegister) return reply(mess.only.registrarB)
 nito.sendMessage(from, {displayname: "Italu🧙‍♂️", vcard: vcard}, MessageType.contact, {quoted: mek})
               nito.sendMessage(from, 'O número do meu dono está acima',MessageType.text, {quoted: mek})
                break
					case 'slow':
					low = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					slo = await nito.downloadAndSaveMediaMessage(low)
					ran = getRandom('.mp3')
					exec(`ffmpeg -i ${slo} -filter:a "atempo=0.7,asetrate=44100" ${ran}`, (err, stderr, stdout) => {
						fs.unlinkSync(slo)
						if (err) return reply('Error!')
						hah = fs.readFileSync(ran)
						nito.sendMessage(from, hah, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek})
						fs.unlinkSync(ran)
					})
				break
				case 'esquilo':
					pai = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo

					tup = await nito.downloadAndSaveMediaMessage(pai)
					ran = getRandom('.mp3')
					exec(`ffmpeg -i ${tup} -filter:a "atempo=0.5,asetrate=65100" ${ran}`, (err, stderr, stdout) => {
						fs.unlinkSync(tup)
						if (err) return reply('Error!')
						hah = fs.readFileSync(ran)
						nito.sendMessage(from, hah, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek})
						fs.unlinkSync(ran)
					})
				break
				case 'gemuk':
					muk = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo

					gem = await nito.downloadAndSaveMediaMessage(muk)
					ran = getRandom('.mp3')
					exec(`ffmpeg -i ${gem} -filter:a "atempo=1.6,asetrate=22100" ${ran}`, (err, stderr, stdout) => {
						fs.unlinkSync(gem)
						if (err) return reply('Error!')
						hah = fs.readFileSync(ran)
						nito.sendMessage(from, hah, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek})
						fs.unlinkSync(ran)
					})
				break
				case 'bass':                 
					ass = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo

					bas = await nito.downloadAndSaveMediaMessage(ass)
					ran = getRandom('.mp3')
					exec(`ffmpeg -i ${bas} -af equalizer=f=64:width_type=o:width=2:g=25 ${ran}`, (err, stderr, stdout) => {
						fs.unlinkSync(bas)
						if (err) return reply('Error!')
						hah = fs.readFileSync(ran)
						nito.sendMessage(from, hah, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek})
						fs.unlinkSync(ran)
					})
					break

				case 'info':
  me = nito.user
  uptime = process.uptime()
  inf =
 `‣ Nome do bot: ${me.name}
  ‣ Número do bot: @${me.jid.split('@')[0]}
  ‣ Dono: Italu
  ‣ Prefix: ${prefix}
  ‣ Total de usuários bloqueados: ${blocked.length}
  ‣ O bot está ativo há: ${kyun(uptime)}
  ‣ Total de usuários: ${_registered.length} usuários
  ‣ Total chats: ${totalchat.length}`
  buffer = await getBuffer(me.imgUrl)
  nito.sendMessage(from, buffer, image, {caption: inf, contextInfo: {mentionedJid: [me.jid]}})
  break
 

case 'infogp':
case 'infogc':
				case 'groupinfo':
				case 'infogrup':
				case 'grupinfo':
                if (!isRegister) return reply(mess.only.userB)
                nito.updatePresence(from, Presence.composing)
                if (!isGroup) return reply(mess.only.group)
                let { owner, creation, participants, desc } = groupMetadata;
                const creationTime = moment.unix(creation);
                try {
					ppUrl = await nito.getProfilePicture(from)
					} catch {
					ppUrl = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
					}
                reply(mess.wait) 
			    buffer = await getBuffer(ppUrl)
		        nito.sendMessage(from, buffer, image, {quoted: mek, caption: `Nome: ${groupName}\nQuantidade se membros: ${groupMembers.length}\n*Administradores: ${groupAdmins.length}\nDescrição: ${desc ? desc : ''}\nOwner : @${owner.split('@')[0]}_\n_Total Member : ${participants.length}_\n_Tanggal`})
                break

case 'kanna':
fs.readFileSync(`./teste/loli.mp4`), MessageType.video, {mimetype: Mimetype.gif, caption: 'Hi nii-chan!!'}
break

case 'roll':
        const rollNumber = Math.floor(Math.random() * (6 - 1) + 1);
        await nito.sendStickerfromUrl(from, `https://www.random.org/dice/dice${rollNumber}.png`);
        break;
//---Kecepatan respon
case 'ping':
  case 'speed':
if (!isRegister) return reply(mess.only.userB)
const timestamp = speed();
const latensi = speed() - timestamp
nito.updatePresence(from, Presence.composing)
uptime = process.uptime()
nito.sendMessage(from, `Tempo de resposta: ${latensi.toFixed(4)} segundos\n`, text, {
  quoted: mek
})
break

//---donasi
//case 'donasi':
nito.updatePresence(from, Presence.composing)
if (!isRegister) return reply(mess.only.daftarB)
hasil = `Bantu donasi agar bot bisa terus berjalan.

اتَّقوا النَّارَ ولو بشقِّ تمرةٍ ، فمن لم يجِدْ فبكلمةٍ طيِّبةٍ
_“jauhilah api neraka, walau hanya dengan bersedekah sebiji kurma (sedikit). Jika kamu tidak punya, maka bisa dengan kalimah thayyibah” [HR. Bukhari 6539, Muslim 1016]_

*Pulsa :* _${Pulsa}_
*Dana :* _${Dana}_
*OVO :* _${Ovo}_`,
nito.sendMessage(from, hasil, text, {
  quoted: mek
})
break

//--pencarian pinterest
  case 'img':
if (!isRegister) return reply(mess.only.daftarB)
if (args.length < 1) return reply('digite o que você quer buscar')
tels = body.slice(4)
nito.updatePresence(from, Presence.composing)
reply(mess.wait)
try {
data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${tels}`, {
  method: 'get'
})
n = JSON.parse(JSON.stringify(data));
nimek = n[Math.floor(Math.random() * n.length)];
pok = await getBuffer(nimek)
nito.sendMessage(from, pok, image, {
  quoted: mek, caption: `Achei isso sobre: ${tels}`
})

} catch {
  reply(mess.ferr)
}
break

case 'online':
        		let ido = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : from
			    let online = [...Object.keys(nito.chats.get(ido).presences), nito.user.jid]
			    nito.sendMessage(from, 'Lista de usuários online:\n' + online.map(v => '- @' + v.replace(/@.+/, '')).join`\n`, text, { quoted: mek,
  			  contextInfo: { mentionedJid: online }
			    })
				break



//--pinterest anime neko
case 'neko':

if (!isRegister) return reply(mess.only.daftarB)

nito.updatePresence(from, Presence.composing)
uk = ["anime neko"]
nk = uk[Math.floor(Math.random() * uk.length)]
try {
data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${nk}`, {
  method: 'get'
})
reply(mess.wait)
n = JSON.parse(JSON.stringify(data));
nimek = n[Math.floor(Math.random() * n.length)];
pok = await getBuffer(nimek)
nito.sendMessage(from, pok, image, {
  quoted: mek, caption: `nyan`
})

} catch {
  reply(mess.ferr)
}
break

//--Pinteres anime loli
  case 'loli':

if (!isRegister) return reply(mess.only.daftarB)

nito.updatePresence(from, Presence.composing)
uk = ["anime loli"]
nk = uk[Math.floor(Math.random() * uk.length)]
try {
data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${nk}`, {
  method: 'get'
})
reply(mess.wait)
n = JSON.parse(JSON.stringify(data));
nimek = n[Math.floor(Math.random() * n.length)];
pok = await getBuffer(nimek)
nito .sendMessage(from, pok, image, {
  quoted: mek, caption: `nii?`
})

} catch {
  reply(mess.ferr)
}
break

 case 'shitpost':

if (!isRegister) return reply(mess.only.daftarB)

nito.updatePresence(from, Presence.composing)
uk = ["shitpost br"]
nk = uk[Math.floor(Math.random() * uk.length)]
try {
data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${nk}`, {
  method: 'get'
})
reply(mess.wait)
n = JSON.parse(JSON.stringify(data));
nimek = n[Math.floor(Math.random() * n.length)];
pok = await getBuffer(nimek)
nito.sendMessage(from, pok, image, {
  quoted: mek, caption: `إذا قمت بترجمة هذا فأنت سارق🤣👆`
})

} catch {
  reply(mess.ferr)
}
break

  case 'anime':

if (!isRegister) return reply(mess.only.daftarB)

nito.updatePresence(from, Presence.composing)
am = ["anime tumblr",
  "wallpaper anime hd",
  "anime aestethic",
  "anime hd"]
nk = am[Math.floor(Math.random() * am.length)]
data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${nk}`, {
  method: 'get'
})
reply(mess.wait)
n = JSON.parse(JSON.stringify(data));
nimek = n[Math.floor(Math.random() * n.length)];
pok = await getBuffer(nimek)
nito.sendMessage(from, pok, image, {
  quoted: mek, caption: `💮`
})

break

//--Pinterest wallpaper
  case 'wp':
case 'wallpaper':

  if (!isRegister) return reply(mess.only.daftarB)
  
  nito.updatePresence(from, Presence.composing)
  pw = ["wallpaper aestethic",
"wallpaper tumblr",
"wallpaper lucu",
"wallpaper"]
  nk = pw[Math.floor(Math.random() * pw.length)]
  try {
  data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${nk}`, {
method: 'get'
  })
  reply(mess.wait)
  n = JSON.parse(JSON.stringify(data));
  nimek = n[Math.floor(Math.random() * n.length)];
  pok = await getBuffer(nimek)
  nito.sendMessage(from, pok, image, {
quoted: mek, caption: `keren gak ?`
  })
  
  } catch {
    reply(mess.ferr)
  }
  break
//TESTES



				case 'nsfwloli':
					if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
					loli.getNSFWLoli(async (err, res) => {
						if (err) return reply('❌ *ERROR* ❌')
						buffer = await getBuffer(res.url)
						nito.sendMessage(from, buffer, image, {quoted: mek, caption: 'Jangan jadiin bahan buat comli om'})
					})
					break
                  case 'nsfw':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					//if (!isOwner) return reply(mess.only.ownerB)
					if (args.length < 1) return reply('Digite =nsfw 1 para ativar')
					if (Number(args[0]) === 1) {
						if (isNsfw) return reply('O NSFW já está ativo no grupo')
						nsfw.push(from)
						fs.writeFileSync('./database/json/nsfw.json', JSON.stringify(nsfw))
						reply('Função NSFW ativada no grupo')
					} else if (Number(args[0]) === 0) {
						nsfw.splice(from, 1)
						fs.writeFileSync('./database/json/nsfw.json', JSON.stringify(nsfw))
						reply('Função NSFW desativada no grupo')
					} else {
						reply('Digite =nsfw 1 para ativar, 0 para desativar o recurso')
					}
					break
                   
                   case 'leveis':
                if (!isGroup) return reply(mess.only.group)
                if (!isGroupAdmins) return reply(mess.only.admin)
                if (args.length < 1) return reply(`Digite da forma correta:\nComando: ${prefix}leveis 1, para ativar e 0 para desativar`)
                if (Number(args[0]) === 1) {
                if (isLevelingOn) return reply('Função leveis já está ativada no grupo')
                 	   _leveling.push(from)
                 	   fs.writeFileSync('./datauser/leveling.json', JSON.stringify(_leveling))
                  	   reply('Função leveis foi ativada')
              	  } else if (Number(args[0]) === 0) {
                  	  _leveling.splice(from, 1)
                 	   fs.writeFileSync('./datauser/leveling.json', JSON.stringify(_leveling))
                 	    reply('Função leveis foi desativada')
             	   } else {
                 	   reply(`Digite da forma correta:\nComando: ${prefix}leveis 1, para ativar e 0 para desativar`)
                	}
				break


case 'nomeninja':
  if (args.length < 1) return reply('escreva seu nome')
nito.updatePresence(from, Presence.composing)
if (!isRegister) return reply(mess.only.daftarB)
nome = body.slice(10)
try {
data = await fetchJson(`https://api.terhambar.com/ninja?nama=${nome}`)
hasil = `Seu nome de ninja:\n\n${data.result.ninja}`
reply(hasil)

} catch {
  reply(mess.ferr)
}
break

case 'apakah':
  if (args.length < 1) return reply('*☒* Masukan pertanyaan')
  nito.updatePresence(from, Presence.composing)
  random = apakah[Math.floor(Math.random() * (apakah.length))]
  hasil = `Apakah : ${body.slice(8)}*\n\nJawaban : ${random}*`
  reply(hasil)
  break

//bisakah
case 'bisakah':
  if (args.length < 1) return reply('*☒* Masukan pertanyaan')
  nito.updatePresence(from, Presence.composing)
  if (!isRegister) return reply(mess.only.daftarB)
  random = bisakah[Math.floor(Math.random() * (bisakah.length))]
  hasil = `Bisakah : ${body.slice(9)}*\n\nJawaban : ${random}*`
  reply(hasil)
  break

case 'rate':
  if (args.length < 1) return reply('*☒* Masukan pertanyaan')
  nito.updatePresence(from, Presence.composing)
  if (!isRegister) return reply(mess.only.daftarB)
  random = `${Math.floor(Math.random() * 100)}`
  hasil = `Rating : ${body.slice(6)}*\n\nJawaban : ${random}%*`
  reply(hasil)
  break

case 'kapankah':
  if (args.length < 1) return reply('*☒* Masukan pertanyaan')
  nito.updatePresence(from, Presence.composing)
  if (!isRegister) return reply(mess.only.daftarB)
  random = kapankah[Math.floor(Math.random() * (kapankah.length))]
  random2 = `${Math.floor(Math.random() * 8)}`
  hasil = `Kapankah : ${body.slice(10)}*\n\nJawaban : ${random2} ${random}*`
  reply(hasil)
  break

case 'kapan':
  if (args.length < 1) return reply('*☒* Masukan pertanyaan')
  nito.updatePresence(from, Presence.composing)
  if (!isRegister) return reply(mess.only.daftarB)
  random = kapankah[Math.floor(Math.random() * (kapankah.length))]
  random2 = `${Math.floor(Math.random() * 8)}`
  hasil = `Kapankah : ${body.slice(7)}*\n\nJawaban : ${random2} ${random}*`
  reply(hasil)
  break

case 'setppgc':

if (!isGroup) return reply(mess.only.group)
if (!isRegister) return reply(mess.only.daftarB)
if (!isGroupAdmins) return reply(mess.only.admin)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
const ftgp = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: mek
reply(mess.wait)
const medipp = await nito.downloadAndSaveMediaMessage(ftgp)
await nito.updateProfilePicture (from, medipp)
reply('foto do grupo alterada')
break

case 'triggered':
case 'ger':
 if (!isRegister) return reply(mess.only.userB)
            var imgbb = require('imgbb-uploader')
           if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
           ger = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
           reply(mess.waitimg)
         owgi = await nito.downloadAndSaveMediaMessage(ger)
           anu = await imgbb("e249fbc8046a925d28aa1d42751083bf", owgi)
        imgtrg = `${anu.display_url}`
         ranp = getRandom('.gif')
        rano = getRandom('.webp')
        anu1 = `https://some-random-api.ml/canvas/triggered?avatar=${imgtrg}`
       exec(`wget ${anu1} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
                                                fs.unlinkSync(ranp)
                                                if (err) return reply(mess.error.stick)
                                                nobg = fs.readFileSync(rano)
                                                nito.sendMessage(from, nobg, sticker, {quoted: mek})
                                                fs.unlinkSync(rano)
                                        })
                                    
                                             } else {
                                                 reply('Você precisa marcar ou enviar uma imagem para isso')
                                          }
                                             break


case 'tourl':
 if (!isRegister) return reply(mess.only.userB)
            var imgbb = require('imgbb-uploader')
           if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
           ger = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
           reply(mess.wait)
         owgi = await nito.downloadAndSaveMediaMessage(ger)
           anu = await imgbb("e249fbc8046a925d28aa1d42751083bf", owgi)
        imurl = `${anu.display_url}`
reply(imurl)
}
break

case 'wasted':
if (!isRegister) return reply(mess.only.userB)
var imgbb = require('imgbb-uploader')
if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
  ger = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: mek
  reply(mess.waitimg)
  owgi = await nito.downloadAndSaveMediaMessage(ger)
  anu = await imgbb("e249fbc8046a925d28aa1d42751083bf", owgi)
  imgwas = `${anu.display_url}`
  hehe = await getBuffer(`https://some-random-api.ml/canvas/wasted?avatar=${imgwas}`)
 nito.sendMessage(from, hehe, image, {quoted:mek})
} else {
  reply('Você precisa marcar ou enviar uma imagem')
}
break

case 'drawing':
if (!isRegister) return reply(mess.only.userB)
var imgbb = require('imgbb-uploader')
if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
  ted = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: mek
  reply(mess.waitimg)
  owgi = await nito.downloadAndSaveMediaMessage(ted)
  tels = body.slice(7)
  anu = await imgbb("e249fbc8046a925d28aa1d42751083bf", owgi)
  hehe = await getBuffer(`https://videfikri.com/api/textmaker/pencil/?urlgbr=${anu.display_url}`)
 nito.sendMessage(from, hehe, image, {quoted:mek})
} else {
  reply('Você precisa marcar ou enviar uma imagem')
}
break


case 'wanted':
if (!isRegister) return reply(mess.only.userB)
var imgbb = require('imgbb-uploader')
if ((isMedia && !mek.message.videoMessage || isQuotedImage)) {
  ted = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: mek
if (args.length < 1) return reply(`Digite algum texto para isso`)
  wtext = body.slice(7)
  reply(mess.waitimg)
  owgi = await nito.downloadAndSaveMediaMessage(ted)
  anu = await imgbb("e249fbc8046a925d28aa1d42751083bf", owgi)
  hehe = await getBuffer(`https://videfikri.com/api/textmaker/wanted/?urlgbr=${anu.display_url}&text1=${wtext}&text2=10000`)
 nito.sendMessage(from, hehe, image, {quoted:mek})
} else {
  reply('Você precisa marcar ou enviar uma imagem')
}
break

case '8bit':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply(`Digite da forma correta:\nComando: ${prefix}8bit texto1|texto2`)
if (!q.includes('|')) return reply(`Digite da forma correta:\nComando: ${prefix}8bit texto1|texto2`)
pc = body.slice(5)
  tx1 = pc.split("|")[0];
  tx2 = pc.split("|")[1];
reply(mess.waitimg)
hehe = await getBuffer(`https://videfikri.com/api/textmaker/8bit/?text1=${tx1}&text2=${tx2}`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'bneon':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
pc = body.slice(6)
reply(mess.waitimg)
hehe = await getBuffer(`https://api.zeks.xyz/api/bneon?apikey=apivinz&text=${pc}`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'matrix':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
pc = body.slice(7)
reply(mess.waitimg)
hehe = await getBuffer(`https://api.zeks.xyz/api/matrix?apikey=apivinz&text=${pc}`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'breakwall':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
pc = body.slice(10)
reply(mess.waitimg)
hehe = await getBuffer(`https://api.zeks.xyz/api/breakwall?apikey=apivinz&text=${pc}`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'dropwater':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
pc = body.slice(10)
reply(mess.waitimg)
hehe = await getBuffer(`https://api.zeks.xyz/api/dropwater?apikey=apivinz&text=${pc}`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'wolflogo':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply(`Digite da forma correta:\nComando: ${prefix}wolflogo texto1|texto2`)
if (!q.includes('|')) return reply(`Digite da forma correta:\nComando: ${prefix}wolflogo texto1|texto2\nNão esqueça do: | `)
pc = body.slice(9)
  tx1 = pc.split("|")[0];
  tx2 = pc.split("|")[1];
reply(mess.waitimg)
hehe = await getBuffer(`https://api.zeks.xyz/api/wolflogo?apikey=apivinz&text1=${tx1}&text2=${tx2}`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break
///--photoOXY
case 'flowertext':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
pc = body.slice(11)
reply(mess.waitimg)
hehe = fetchJson(`https://api.zeks.xyz/api/flowertext?text=${pc}&apikey=apivinz`)
heh = await getBuffer(hehe.result)
nito.sendMessage(from, heh, image, {quoted:mek})
break
///--photoOXY

case 'lovepaper':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
pc = body.slice(10)
reply(mess.waitimg)
hehe = await getBuffer(`https://videfikri.com/api/textmaker/lovemsg/?text=${pc}`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'tfire':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
pc = body.slice(6)
reply(mess.waitimg)
hehe = await getBuffer(`https://api.zeks.xyz/api/tfire?text=${pc}&apikey=apivinz`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'sandw':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
pc = body.slice(6)
reply(mess.waitimg)
hehe = await getBuffer(`https://api.zeks.xyz/api/sandw?apikey=apivinz&text=${pc}`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'firofiro':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
pc = body.slice(9)
reply(mess.waitimg)
hehe = await getBuffer(`https://api.zeks.xyz/api/epep?text=${pc}&apikey=apivinz`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'text3d2':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
pc = body.slice(8)
reply(mess.waitimg)
hehe = await getBuffer(`https://api.zeks.xyz/api/text3dbox?apikey=apivinz&text=${pc}`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'text3d':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
pc = body.slice(7)
reply(mess.waitimg)
hehe = await getBuffer(`https://api.zeks.xyz/api/text3d?text=${pc}&apikey=apivinz`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'phlogo':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
if (!q.includes('|')) return reply(`Digite da forma correta:\nComando: ${prefix}phlogo texto1|texto2\nNão esqueça do: | `)
pc = body.slice(7)
  tx1 = pc.split("|")[0];
  tx2 = pc.split("|")[1];
reply(mess.waitimg)
hehe = await getBuffer(`https://api.zeks.xyz/api/phlogo?text1=${tx1}&text2=${tx2}&apikey=apivinz`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'bpink':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
pc = body.slice(6)
reply(mess.waitimg)
hehe = await getBuffer(`https://api.zeks.xyz/api/logobp?text=${pc}&apikey=apivinz`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'folhas':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
pc = body.slice(7)
reply(mess.waitimg)
hehe = await getBuffer(`https://api.zeks.xyz/api/leavest?text=${pc}&apikey=apivinz`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'tlight':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
pc = body.slice(7)
reply(mess.waitimg)
hehe = await getBuffer(`https://api.zeks.xyz/api/tlight?text=${pc}&apikey=apivinz`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break


case 'narutobanner':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
pc = body.slice(14)
reply(mess.waitimg)
hehe = await getBuffer(`https://videfikri.com/api/textmaker/narutobanner/?text=${pc}`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'romancetext':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
pc = body.slice(12)
reply(mess.waitimg)
hehe = await getBuffer(`https://videfikri.com/api/textmaker/romancetext/?text=${pc}`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'shadowtext':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
pc = body.slice(11)
reply(mess.waitimg)
hehe = await getBuffer(`https://videfikri.com/api/textmaker/shadowtext/?text=${pc}`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'tiktokeffect':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply(`Digite da forma correta:\nComando: ${prefix}tiktokeffect texto1|texto2`)
if (!q.includes('|')) return reply(`Digite da forma correta:\nComando: ${prefix}tiktokeffect texto1|texto2`)
pc = body.slice(13)
nomor = pc.split("|")[0];
pesan = pc.split("|")[1];
if (nomor.length >= 9 ) return reply(`Texto 1 máximo 9 carateres`)
if (pesan.length >= 35 ) return reply(`Texto 2 máximo 35 carateres`)
reply(mess.waitimg)
hehe = await getBuffer(`https://videfikri.com/api/textmaker/tiktokeffect/?text1=${nomor}&text2=${pesan}`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'neon':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
pc = body.slice(5)
if (pc.length >= 80 ) return reply(`Máximo 80 carateres`)
reply(mess.waitimg)
hehe = await getBuffer(`https://videfikri.com/api/textmaker/glowingneon/?text=${pc}`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'hpotter':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
pc = body.slice(8)
reply(mess.waitimg)
hehe = await getBuffer(`https://videfikri.com/api/textmaker/hpotter/?text=${pc}`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'gaming':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
pc = body.slice(7)
reply(mess.waitimg)
hehe = await getBuffer(`https://docs-jojo.herokuapp.com/api/gaming?text=${pc}`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'yuri':
if (!isRegister) return reply(mess.only.userB)
hehe = await getBuffer(`https://docs-jojo.herokuapp.com/api/random_yuri`)
nito.sendMessage(from, hehe, image, {quoted:mek})
break

case 'cep':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite o cep que deseja buscar')
cep = body.slice(4)
hehe = await fetchJson(`https://brasilapi.com.br/api/cep/v1/${cep}`)
if (hehe.error) return reply(hehe.error)
ccg =
` INFORMAÇÕES DO CEP
  ‣ Cep: ${hehe.cep}
  ‣ Estado: ${hehe.state}
  ‣ Cidade: ${hehe.city}`
nito.sendMessage(from, ccg, text, {quoted:mek})
break

case 'booty':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite algum texto para isso')
cep = body.slice(4)
hehe = await fetchJson(`https://meme-api.herokuapp.com/gimme/animebooty`)
if (hehe.error) return reply(hehe.error)
ccg = `${hehe.url}`
buff = await getBuffer(ccg)
buf = await getBuffer(hehe)
nito.sendMessage(from, buff, text, {quoted:mek})
nito.sendMessage(from, buf, text, {quoted:mek})
break

case 'ddd':
if (!isRegister) return reply(mess.only.userB)
if (args.length < 1) return reply('digite o ddd que deseja buscar')
ddd = body.slice(4)
hehe = await fetchJson(`https://brasilapi.com.br/api/ddd/v1/${ddd}`)
if (hehe.error) return reply(hehe.error)
ccg =
` INFORMAÇÕES DO DDD
  ‣ Estado: ${hehe.state}
  ‣ Cidades: 
    ${hehe.cities}\n`
nito.sendMessage(from, ccg, text, {quoted:mek})
break

case 'cartão':
case 'cartao':
if (!isRegister) return reply(mess.only.userB)
hehe = await fetchJson(`https://videfikri.com/api/ccgenerator/`)
if (hehe.error) return reply(hehe.error)
ccg =
` Cartão gerado com sucesso
   ‣ Bandeira: ${hehe.result.card.network}
   ‣ Número: ${hehe.result.card.number}
   ‣ Cvv: ${hehe.result.card.cvv}
   ‣ Pin: ${hehe.result.card.pin}
   ‣ Balanço: ${hehe.result.card.balance}
   ‣ Validade: ${hehe.result.card.expiration_month}/${hehe.result.card.expiration_year}`
nito.sendMessage(from, ccg, text, {quoted:mek})
break

case 'gtav':
if (!isRegister) return reply(mess.only.userB)
var imgbb = require('imgbb-uploader')
if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
  ted = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: mek
  reply(mess.wait)
  owgi = await nito.downloadAndSaveMediaMessage(ted)
  tels = body.slice(7)
  anu = await imgbb("e249fbc8046a925d28aa1d42751083bf", owgi)
  hehe = await getBuffer(`https://videfikri.com/api/textmaker/gtavposter/?urlgbr=${anu.display_url}`)
 nito.sendMessage(from, hehe, image, {quoted:mek})
} else {
  reply('Você precisa marcar ou enviar uma imagem')
}
break

//--list Códigobahasa
case 'ts':
nito.sendMessage(from, bahasa(prefix, sender), text, {
  quoted: mek
})
break

//--link wame
case 'wa.me':
case 'wame':
  nito.updatePresence(from, Presence.composing)
  options = {
text: `Seu link wa.me: wa.me/${sender.split("@s.whatsapp.net")[0]}\nOu: \napi.whatsapp.com/send?phone=${sender.split("@")[0]}`,
contextInfo: {
  mentionedJid: [sender]
}
  }
  nito.sendMessage(from, options, text, {
quoted: mek
  })
  break

//--translate semua bahasa
  case 'tl':
    if (!isRegister) return reply(mess.only.daftarB)
  
if (args.length < 1) return nito.sendMessage(from, `digite da forma correta: ${prefix}tl texto/língua`, text, {
  quoted: mek
})
var pc = body.slice(4)
nomor = pc.split("/")[0];
pesan = pc.split("/")[1];
try {
data = await fetchJson(`https://api-translate.azharimm.tk/translate?engine=google&text=${nomor}&to=${pesan}`)
if (!isRegister) return reply(mess.only.daftarB)
hasil = `Traduzir:\n${data.data.result}`
reply(hasil)

} catch {
  reply(mess.ferr)
}
break

//--fake reply
case 'fitnah':
if (args.length < 1) return reply(`Usage :\n${prefix}fitnah [@tag|pesan|balasanbot]]\n\nEx : \n${prefix}fitnah @tagmember|hai|hai juga`)
var gh = body.slice(7)
mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
var replace = gh.split("|")[0];
var target = gh.split("|")[1];
var bot = gh.split("|")[2];
nito.sendMessage(from, `${bot}`, text, {
  quoted: {
key: {
  fromMe: false, participant: `${mentioned}`, ...(from ? {
remoteJid: from
  }: {})
}, message: {
  conversation: `${target}`
}}})
break

//--Kejujuran
case 'truth':
const ttrth = trut[Math.floor(Math.random() * trut.length)]
nito.sendMessage(from, `‣ *TRUTH*\n${ttrth}`, text, {
  quoted: mek
})
break

//---Tantangan
  case 'dare':
const der = dare[Math.floor(Math.random() * dare.length)]
nito.sendMessage(from, `‣ *DARE*\n${der}`, text, {
  quoted: mek
})
break


//--notifikasi grup
  case 'notif':

if (!isGroupAdmins) return reply(mess.only.admin)
nito.updatePresence(from, Presence.composing)
if (!isRegister) return reply(mess.only.daftarB)
if (!isGroup) return reply(mess.only.group)
if(args.length < 1) return nito.reply('escreva algo como aviso')
aviso  = `Aviso de: @${sender.split("@")[0]}\n\nAviso: ${body.slice(7)}`
group = await nito.groupMetadata(from);
member = group['participants']
jids = [];
member.map(async adm => {
  jids.push(adm.id.replace('c.us', 's.whatsapp.net'));
})
options = {
  text: aviso,
  contextInfo: {
mentionedJid: jids
  },
  quoted: mek
}
await nito.sendMessage(from, options, text)
break

//---Ganti nama grup
  case 'setname':
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return reply(mess.only.admin)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
let idgrup = `${from.split("@s.whatsapp.net")[0]}`;
nito.groupUpdateSubject(idgrup, `${body.slice(9)}`)
nito.sendMessage(from, 'o nome do grupo foi alterado', text, {
  quoted: mek
})
break

//--ganti desk
  case 'setdesk':
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return reply(mess.only.admin)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
nito.groupUpdateDescription(from, `${body.slice(9)}`)
nito.sendMessage(from, 'a descrição do grupo atualizada', text, {
  quoted: mek
})
break


//--tagme
case 'tagme':
if (!isRegister) return reply(mess.only.daftarB)
const tagme = {
  text: `@${sender.split("@")[0]} 🧙‍♂️`,
  contextInfo: {mentionedJid: [sender]
  }
}
nito.sendMessage(from, tagme, text)
break

case 'play':

  if (!isRegister) return reply(mess.only.daftarB)
  
  if (args.length < 1) return reply('Digite o nome da música')
  reply(mess.wait)
  play = body.slice(6)
  try {
  anu = await fetchJson(`https://api.zeks.xyz/api/ytplaymp3?q=${play}&apikey=apivinz`)
  if (anu.error) return reply(anu.error)
  infomp3 = 
`    MÚSICA ENCONTRADA
   ‣ Título: ${anu.result.title}
   ‣ Fonte: ${anu.result.source}
   ‣ Link: ${anu.result.url_audio} `
  buffer = await getBuffer(anu.result.thumbnail)
  lagu = await getBuffer(anu.result.url_audio)
  nito.sendMessage(from, buffer, image, {
quoted: mek, caption: infomp3
  })
  nito.sendMessage(from, lagu, audio, {mimetype: 'audio/mp4', filename: `${anu.result.title}.mp3`, quoted: mek})
  
  } catch {
    reply('servidor off')
  }
  break



case 'ytsearch':
  if (!isRegister) return reply(mess.only.daftarB)
  if (args.length < 1) return reply('Digite o que deseja procurar')
  reply(mess.wait)
  play = body.slice(9)
  try {
  anu = await fetchJson(`https://videfikri.com/api/ytplay/?query=${play}`)
  if (anu.error) return reply(anu.error)
  infomp3 = 
`    MÚSICA ENCONTRADA
   ‣ Título: ${anu.result.title}
   ‣ Fonte: ${anu.result.source}
   ‣ Canal: ${anu.result.channel}
   ‣ Link: ${anu.result.url} 
   ‣ Duração: ${anu.result.duration}
   ‣ Tamanho: ${anu.result.size}
`
  buffer = await getBuffer(anu.result.thumbnail)
  lagu = await getBuffer(anu.result.url)
  nito.sendMessage(from, buffer, image, {
quoted: mek, caption: infomp3
  })
  } catch {
    reply(mess.ferr)
  }
  break


case 'ytmp3':

  if (!isRegister) return reply(mess.only.daftarB)
  
  reply(mess.wait)
  play = body.slice(7)
  if(!isUrl(args[0]) && !args[0].includes('youtu')) return reply('Esse link não é do YouTube')
  try {
  anu = await fetchJson(`https://api.zeks.xyz/api/ytmp3/2?url=${play}&apikey=apivinz`)
  infomp3 = `INFORMAÇÕES DO ÁUDIO\n‣ Título: ${anu.result.title}\n‣ Fonte: ${anu.result.source}\n‣ Tamanho: ${anu.result.size}\nLink: ${anu.result.link}`
  buffer = await getBuffer(anu.result.thumb)
  lagu = await getBuffer(anu.result.link)
  nito.sendMessage(from, buffer, image, {
quoted: mek, caption: infomp3
  })
  nito.sendMessage(from, lagu, audio, {
mimetype: 'audio/mp4', filename: `${anu.result.title}.mp3`, quoted: mek
  })
  
  } catch {
    reply(mess.ferr)
  }
  break

case 'ytmp4':

  if (!isRegister) return reply(mess.only.daftarB)
  
  reply(mess.wait)
  play = body.slice(7)
  try {
  anu = await fetchJson(`https://api.zeks.xyz/api/ytmp4?url=${play}&apikey=apivinz`)
  if(!isUrl(args[0]) && !args[0].includes('youtu')) return reply('Esse link não é do YouTube')
  if (anu.error) return reply(anu.error)
  infomp3 = `INFORMAÇÕES DO VÍDEO\n‣ Título: ${anu.result.title}\n‣ Fonte: ${anu.result.source}\n‣ Tamanho: ${anu.result.size}\nLink: ${anu.result.url_video}`
  buffer = await getBuffer(anu.result.thumbnail)
  lagu = await getBuffer(anu.result.url_video)
  nito.sendMessage(from, buffer, image, {
quoted: mek, caption: infomp3
  })
  nito.sendMessage(from, lagu, video, {
mimetype: 'video/mp4', filename: `${anu.result.title}.mp4`, quoted: mek
  })
  
  } catch {
    reply(mess.ferr)
  }
  break

//--download pinterest
case 'pin':
  if (!isRegister) return reply(mess.only.daftarB)
  
    if(!isUrl(args[0]) && !args[0].includes('pin')) return reply('Format link salah, gunakan link pinterest')
  reply(mess.wait)
  play = body.slice(5)
  try {
  anu = await fetchJson(`https://scrap.terhambar.com/pin?url=${play}`)
  if (anu.error) return reply(anu.error)
  n = JSON.parse(JSON.stringify(anu.result.data));
  lagu = await getBuffer(anu.result)
  nito.sendMessage(from, lagu, video, {
mimetype: 'video/mp4', filename: `${anu.result}.mp4`, quoted: mek
  })
  
  } catch {
    reply(mess.ferr)
  }
  break

//--block user
				case 'blocklist':
					bli = 'Lista de usuários bloqueados:\n'
                    if (!isOwner) return reply(mess.only.ownerB)
					for (let block of blocked) {
						bli += `~> @${block.split('@')[0]}\n`
					}
					bli += `Total: ${blocked.length}`
					nito.sendMessage(from, bli.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": blocked}})
					break

//--read text on image
				case 'ocr':
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						const ocrt = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const com = await nito.downloadAndSaveMediaMessage(ocrt)
						reply(mess.wait)
						await recognize(com, {lang: 'eng+ind', oem: 1, psm: 3})
							.then(oc => {
								reply(oc.trim())
								fs.unlinkSync(com)
							})
							.catch(err => {
								reply(err.message)
								fs.unlinkSync(com)
							})
					} else {
						reply(`Marque ou envie uma imagem com ${prefix}ocr para capturar o texto da imagem`)
					}
					break
//--pacote de sticker especial

                case 'fign':
					if ((isMedia && !mek.message.videoMessage || isQuotedImage)) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await nito.downloadAndSaveMediaMessage(encmedia)
                     if (!q.includes('|')) return reply(`Você deve digitar o nome do pacote e criador dessa forma:\nComando: ${prefix}fign nome do pack|nome do autor\nExemplo: ${prefix}fign Pack nagatoro1|Italu`)
                        nomes = body.slice(5)
                        pack = nomes.split("|")[0];
                        autor = nomes.split("|")[1];
						ran = getRandom('.webp')
						await ffmpeg(`./${media}`)
							.input(media)
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								reply(mess.error.stick)
							})
							.on('end', function () {
								console.log('Finish')
								exec(`webpmux -set exif ${addMetadata(pack, autor)} ${ran} -o ${ran}`, async (error) => {
									if (error) return reply(mess.error.stick)
									nito.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
									fs.unlinkSync(media)	
									fs.unlinkSync(ran)	
                                     })
                                    })
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(180,iw)':min'(180,ih)':force_original_aspect_ratio=decrease,fps=20, pad=180:180:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else if ((isMedia && mek.message.videoMessage.seconds < 11 || isQuotedVideo && mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11)) {
						const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await nito.downloadAndSaveMediaMessage(encmedia)
                      if (!q.includes('|')) return reply(`Você deve digitar o nome do pacote e criador dessa forma:\nComando: ${prefix}fign nome do pack|nome do autor\nExemplo: ${prefix}fign Pack nagatoro1|Italu`)
                        nomes = body.slice(5)
                        pack = nomes.split("|")[0];
                        autor = nomes.split("|")[1];
						ran = getRandom('.webp')
						reply(mess.wait)
						await ffmpeg(`./${media}`)
							.inputFormat(media.split('.')[1])
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								tipe = media.endsWith('.mp4') ? 'video' : 'gif'
								reply(`A conversão de ${tipe} para o sticker falhou`)
							})
							.on('end', function () {
								console.log('Finish')
                                metada = 
								exec(`webpmux -set exif ${addMetadata(pack, autor)} ${ran} -o ${ran}`, async (error) => {
									if (error) return reply(mess.error.stick)
									nito.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
									fs.unlinkSync(media)
									fs.unlinkSync(ran)
								})
                                    })
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(180,iw)':min'(180,ih)':force_original_aspect_ratio=decrease,fps=20, pad=180:180:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else if ((isMedia || isQuotedImage) && args[0] == 'nobg') {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await nito.downloadAndSaveMediaMessage(encmedia)
						ranw = getRandom('.webp')
						ranp = getRandom('.png')
						reply(mess.wait)
						keyrmbg = 'sfFSzxRz7y6jYDwfxx47rCgz'
						await removeBackgroundFromImageFile({path: media, apiKey: keyrmbg, size: 'auto', type: 'auto', ranp}).then(res => {
							fs.unlinkSync(media)
							let buffer = Buffer.from(res.base64img, 'base64')
							fs.writeFileSync(ranp, buffer, (err) => {
								if (err) return reply('ocorreu um erro')
							})
							exec(`ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${ranw}`, (err) => {
								fs.unlinkSync(ranp)
								if (err) return reply(mess.error.stick)
								exec(`webpmux -set exif ${addMetadata('Tiringa-BOT', authorname)} ${ranw} -o ${ranw}`, async (error) => {
									if (error) return reply(mess.error.stick)
									nito.sendMessage(from, fs.readFileSync(ranw), sticker, {quoted: mek})
									fs.unlinkSync(ranw)
								})
							})
						})
					} else {
						reply(`Limite de 10 segundos por gif/video`)
					}
					break

//--pacote de sticker especial

//--stiker maker
				case 's':
				case 'stiker':
				case 'sticker':
				case 'stickergif':
				case 'stikergif':
                case 'fig':
                case 'gif':
                case 'figura':
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await nito.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						await ffmpeg(`./${media}`)
							.input(media)
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								reply(mess.error.stick)
							})
							.on('end', function () {
								console.log('Finish')
								exec(`webpmux -set exif ${addMetadata('Tiringa-BOT', authorname)} ${ran} -o ${ran}`, async (error) => {
									if (error) return reply(mess.error.stick)
									nito.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
									fs.unlinkSync(media)	
									fs.unlinkSync(ran)	
                                     })
                                    })
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(180,iw)':min'(180,ih)':force_original_aspect_ratio=decrease,fps=15, pad=180:180:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else if ((isMedia && mek.message.videoMessage.seconds < 11 || isQuotedVideo && mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11) && args.length == 0) {
						const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await nito.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						reply(mess.wait)
						await ffmpeg(`./${media}`)
							.inputFormat(media.split('.')[1])
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								tipe = media.endsWith('.mp4') ? 'video' : 'gif'
								reply(`A conversão de ${tipe} para o sticker falhou`)
							})
							.on('end', function () {
								console.log('Finish')
								exec(`webpmux -set exif ${addMetadata('Tiringa-BOT', authorname)} ${ran} -o ${ran}`, async (error) => {
									if (error) return reply(mess.error.stick)
									nito.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
									fs.unlinkSync(media)
									fs.unlinkSync(ran)
								})
                                    })
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(180,iw)':min'(180,ih)':force_original_aspect_ratio=decrease,fps=15, pad=180:180:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else if ((isMedia || isQuotedImage) && args[0] == 'nobg') {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await nito.downloadAndSaveMediaMessage(encmedia)
						ranw = getRandom('.webp')
						ranp = getRandom('.png')
						reply(mess.wait)
						keyrmbg = 'sfFSzxRz7y6jYDwfxx47rCgz'
						await removeBackgroundFromImageFile({path: media, apiKey: keyrmbg, size: 'auto', type: 'auto', ranp}).then(res => {
							fs.unlinkSync(media)
							let buffer = Buffer.from(res.base64img, 'base64')
							fs.writeFileSync(ranp, buffer, (err) => {
								if (err) return reply('ocorreu um erro')
							})
							exec(`ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${ranw}`, (err) => {
								fs.unlinkSync(ranp)
								if (err) return reply(mess.error.stick)
								exec(`webpmux -set exif ${addMetadata('Tiringa-BOT', authorname)} ${ranw} -o ${ranw}`, async (error) => {
									if (error) return reply(mess.error.stick)
									nito.sendMessage(from, fs.readFileSync(ranw), sticker, {quoted: mek})
									fs.unlinkSync(ranw)
								})
							})
						})
					} else {
						reply(`Limite de 10 segundos por gif/video`)
					}
					break
                    case 'st':

if (!isRegister) return reply(mess.only.registrarB)
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await nito.downloadAndSaveMediaMessage(encmedia)                                     
						rano = getRandom('.webp')
						await ffmpeg(`./${media}`)
							.input(media)
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
                                exec(`webpmux -set exif ${addMetadata('Tiringa-BOT', authorname)} ${rano} -o ${rano}`, async (error) => {
								fs.unlinkSync(media)
								reply(mess.error.stick)
							})
                      })
							exec(`ffmpeg -i ${media} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 800:800 ${rano}`, (err) => {
							fs.unlinkSync(media)
						buffer = fs.readFileSync(rano)
						nito.sendMessage(from, buffer, sticker, {quoted: mek})
						fs.unlinkSync(rano)
                        })
						} else if ((isMedia && mek.message.videoMessage.seconds < 11 || isQuotedVideo && mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11) && args.length == 0) {
						const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await nito.downloadAndSaveMediaMessage(encmedia)
						rano = getRandom('.webp')
						reply(mess.waitgif)
						await ffmpeg(`./${media}`)
							.inputFormat(media.split('.')[1])
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
                                exec(`webpmux -set exif ${addMetadata('Tiringa-BOT', authorname)} ${rano} -o ${rano}`, async (error) => {
								fs.unlinkSync(media)
								tipe = media.endsWith('.mp4') ? 'video' : 'gif'
								reply(`Falha na conversão de ${tipe} para sticker`)
							})
                      })
							exec(`ffmpeg -i ${media} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 200:200 ${rano}`, (err) => {
							fs.unlinkSync(media)
						buffer = fs.readFileSync(rano)
						nito.sendMessage(from, buffer, sticker, {quoted: mek})
						fs.unlinkSync(rano)
					    })
						} else {
						reply(`Limite de 10 segundos por gif/video`)
					}
					break
                      

//-- temp
			case 'gets':
			  
				var itsme = `0@s.whatsapp.net`
				var split = `${cr}`
				var selepbot = {
					contextInfo: {
						participant: itsme,
						quotedMessage: {
							extendedTextMessage: {
								text: split,
							}
						}
					}
				}
				namastc = body.slice(6)
				try {
				result = fs.readFileSync(`./temp/stick/${namastc}.webp`)
				nito.sendMessage(from, result, sticker, selepbot)
				} catch {
				  reply('Arquivo não está registrado')
				}
				break
			
			
			  case 'getstik':
				var itsme = `0@s.whatsapp.net`
				var split = `${cr}`
				var selepbot = {
					contextInfo: {
						participant: itsme,
						quotedMessage: {
							extendedTextMessage: {
								text: split,
							}
						}
					}
				}
				namastc = body.slice(9)
				try {
				result = fs.readFileSync(`./temp/stick/${namastc}.webp`)
				nito.sendMessage(from, result, sticker, selepbot)
				} catch {
				  reply('Arquivo não está registrado')
				}
				break
			
			
			
			case 'liststik':
				lt = 'Lista de stickers:\n\n'
				for (let awokwkwk of setiker) {
					lt += `- ${awokwkwk}\n`
				}
				lt += `\n*Total : ${setiker.length}*\nGunakan perintah\n${prefix}getstik (nama pack)*\nuntuk mengambil stiker`
				nito.sendMessage(from, lt.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": setiker } })
				break
			
			case 'totaluser':
				ts = 'Total de usuários:\n\n'
				for (let i of _registered) {
					ts += `[${id.toString()}]\`\`\` @${i.split('@')[0]}`
				}
				ts += `\nTotal: ${_registered.length}`
				nito.sendMessage(from, ts.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": _registered} })
				break

			case 'addstik':
				if (!isQuotedSticker) return reply('marque um sticker')
				if (!isOwner) return reply(mess.only.ownerB)
				svst = body.slice(9)
				if (!svst) return reply('Qual é o nome do sticker?')
				boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
				delb = await nito.downloadMediaMessage(boij)
				setiker.push(`${svst}`)
				fs.writeFileSync(`./temp/stick/${svst}.webp`, delb)
				fs.writeFileSync('./temp/stik.json', JSON.stringify(setiker))
				nito.sendMessage(from, `Sukses Menambahkan Sticker\nCek dengan cara ${prefix}liststik`, MessageType.text, { quoted: mek })
				break

			case 'addvn':
				if (!isQuotedAudio) return reply('marque um áudio')
				if (!isOwner) return reply(mess.only.ownerB)
				svst = body.slice(7)
				if (!svst) return reply('Qual é o nome do áudio?')
				boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
				delb = await nito.downloadMediaMessage(boij)
				audionye.push(`${svst}`)
				fs.writeFileSync(`./temp/audio/${svst}.mp3`, delb)
				fs.writeFileSync('./temp/vn.json', JSON.stringify(audionye))
				nito.sendMessage(from, `Sukses Menambahkan Audio\nCek dengan cara ${prefix}listvn`, MessageType.text, { quoted: mek })
				break

			case 'getvn':
				namastc = body.slice(7)
				try {
				buffer = fs.readFileSync(`./temp/audio/${namastc}.mp3`)
				nito.sendMessage(from, buffer, audio, { mimetype: 'audio/mp4', quoted: mek, ptt: true })
				} catch {
				  reply('Arquivo não está registrado')
				}
				break

			case 'listvn':
			case 'vnlist':
				la = 'Lista de áudios:\n\n'
				for (let awokwkwk of audionye) {
					la += `- ${awokwkwk}\n`
				}
				la += `\nTotal: ${audionye.length}*\nGunakan perintah\n${prefix}getvn (nama pack)*\nuntuk mengambil vn`
				nito.sendMessage(from, la.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": audionye } })
				break

			case 'addimg':
				if (!isQuotedImage) return reply('marque uma imagem')
				if (!isOwner) return reply(mess.only.ownerB)
				svst = body.slice(8)
				if (!svst) return reply('Qual é o nome da imagem?')
				boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
				delb = await nito.downloadMediaMessage(boij)
				imagenye.push(`${svst}`)
				fs.writeFileSync(`./temp/foto/${svst}.jpeg`, delb)
				fs.writeFileSync('./temp/image.json', JSON.stringify(imagenye))
				nito.sendMessage(from, `Sukses Menambahkan Video\nCek dengan cara ${prefix}listimage`, MessageType.text, { quoted: mek })
				break

			case 'getimg':
				namastc = body.slice(8)
				try {
				buffer = fs.readFileSync(`./temp/foto/${namastc}.jpeg`)
				nito.sendMessage(from, buffer, image, { quoted: mek, caption: `Result From Database : ${namastc}.jpeg` })
				} catch {
				  reply('Arquivo não está registrado')
				}
				break
				
			case 'listimg':
				li = 'Lista de imagens:\n\n'
				for (let awokwkwk of imagenye) {
					li += `- ${awokwkwk}\n`
				}
				li += `\n*Total : ${imagenye.length}*\nGunakan perintah\n${prefix}getimg (nama pack)*\nuntuk mengambil gambar`
				nito.sendMessage(from, li.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": imagenye } })
				break

			case 'addvid':
			  if (!isOwner) return reply(mess.only.ownerB)
				if (!isQuotedVideo) return reply('marque um vídeo')
				svst = body.slice(8)
				if (!svst) return reply('Qual o nome do video?')
				boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
				delb = await nito.downloadMediaMessage(boij)
				videonye.push(`${svst}`)
				fs.writeFileSync(`./temp/video/${svst}.mp4`, delb)
				fs.writeFileSync('./temp/vid.json', JSON.stringify(videonye))
				nito.sendMessage(from, `Sukses Menambahkan Video\nCek dengan cara ${prefix}listvid`, MessageType.text, { quoted: mek })
				break

			case 'getvid':
				namastc = body.slice(8)
				try {
				buffer = fs.readFileSync(`./temp/video/${namastc}.mp4`)
				nito.sendMessage(from, buffer, video, { mimetype: 'video/mp4', quoted: mek })
				} catch {
				  reply('Arquivo não está registrado')
				}
				break

			case 'listvid':
				lv = 'Lista de vídeos:\n\n'
				for (let awokwkwk of videonye) {
					lv += `- ${awokwkwk}\n`
				}
				lv += `\nTotal: ${videonye.length}\nUse o comando\n${prefix}getvid (nome do pack)\npara fazer um video`
				nito.sendMessage(from, teks.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": videonye } })
				break



//--stiker to video
  case 'togif':
nito.updatePresence(from,
  Presence.composing)
if (!isRegister) return reply(mess.only.daftarB)
if (!isQuotedSticker) return reply('Você precisa marcar um sticker não animado para isso')
reply(mess.wait)
anumedia = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
anum = await nito.downloadAndSaveMediaMessage(anumedia)
ran = getRandom('.webp')
exec(`ffmpeg -i ${anum} ${ran}`, (err) => {
  fs.unlinkSync(anum)
  if (err) return reply('❌falha ao converter sticker para gif❌')
  buffer = fs.readFileSync(ran)
  nito.sendMessage(from, buffer, video, {
quoted: mek, caption: 'conversão sucedida'
  })
  fs.unlinkSync(ran)
})
break

//--mp4 to mp3
  case 'tomp3':

nito.updatePresence(from,
  Presence.composing)
if (!isRegister) return reply(mess.only.daftarB)
if (!isQuotedVideo) return reply(`Marque um vídeo com ${prefix}tomp3`)
reply(mess.wait)
mitri = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
duh = await nito.downloadAndSaveMediaMessage(mitri)
ran = getRandom('.mp4')
exec(`ffmpeg -i ${duh} ${ran}`, (err) => {
  fs.unlinkSync(duh)
  if (err) return reply('❌falha ao converter video para mp3❌')
  buffer = fs.readFileSync(ran)
  nito.sendMessage(from, buffer, audio, {
mimetype: 'audio/mp4', quoted: mek
  })
  fs.unlinkSync(ran)
})
break

//--google voice
				case 'tts':

					if (args.length < 1) return nito.sendMessage(from, `Você deve usar o comando da forma correta:\n${prefix}tts (língua) (texto)\nExemplo: ${prefix}tts pt bom dia\n\nUse: ${prefix}ts para listar todas as línguas`, text, {quoted: mek})
					const gtts = require('./lib/gtts')(args[0])
					if (args.length < 2) return nito.sendMessage(from, 'Cadê o texto?', text, {quoted: mek})
					dtt = body.slice(8)
					ranm = getRandom('.mp3')
					dtt.length > 800
					? reply('Texto muito grande')
					: gtts.save(ranm, dtt, function() {
						nito.sendMessage(from, fs.readFileSync(ranm), audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
						fs.unlinkSync(ranm)
					})
					break

//-- Setting prefix
				case 'setprefix':
					if (args.length < 1) return
					if (!isOwner) return reply(mess.only.ownerB)
				  prefix = args[0]
					up.prefix = prefix
					fs.writeFileSync('./data/settings.json', JSON.stringify(up, null, '\t'))
					reply(`O prefix foi alterado para: ${prefix}`)
					break


case 'block':
  nito.updatePresence(from, Presence.composing)
  if (!isGroup) return reply(mess.only.group)
  if (!isOwner) return reply(mess.only.ownerB)
  nito.blockUser (`${body.slice(8)}@c.us`, "add")
  nito.sendMessage(from, `Memblokir nomor, Perintah Diterima`, text, {
quoted: mek
  })
  break

//membuka blokir
case 'unblock':
  if (!isGroup) return reply(mess.only.group)
  if (!isOwner) return reply(mess.only.ownerB)
  nito.blockUser (`${body.slice(9)}@c.us`, "remove")
  nito.sendMessage(from, `Membuka blokir, Perintah diterima`, text)
  break

//---Tagall member
				case 'tagall':
nito.updatePresence(from, Presence.composing)
//reply('comando desativado para evitar flood')
if (!isGroup) return reply(mess.only.group)
if (!isRegister) return reply(mess.only.daftarB)
if (!isGroupAdmins) return reply(mess.only.admin)
members_id = []
todos = (args.length > 1) ? body.slice(8).trim(): ''
todos += `Total: ${groupMembers.length} membros\n`
for (let mem of groupMembers) {
  todos += `┃➸@${mem.jid.split('@')[0]}\n`
  members_id.push(mem.jid)
}
mentions('╭╾╼◐⚋ ༒ᴍᴇɴᴄɪᴏɴᴀʀ ᴛᴏᴅᴏs ༒⚋◑╾╼╮\n┃➸'+todos+'╰╾╼◐⚋⚋ ༒ ∴₰Ⱦꪋℓo፝֯֟ ߷ ༒ ⚋⚋◑╾╼╯', members_id, true)
break
//case 'tagall':
				nito.updatePresence(from, Presence.composing) 
					if (!isGroup) return reply(mess.only.group)
                    if (!isRegister) return reply(mess.only.registrarB)
					if (!isGroupAdmins) return reply(mess.only.admin)
                    assunto = body.slice(7)
					members_id = []
					teks = (args.length > 1) ? body.slice(8).trim() : ''
					teks += `  Total : ${groupMembers.length}\n`
					for (let mem of groupMembers) {
						teks += `@${mem.jid.split('@')[0]}\n`
						members_id.push(mem.jid)
					}
					mentions(' Mencionando Todos \n'+assunto+'\n'+teks+'teste', members_id, true)
					break

//clear all chat
				case 'clearall':
					if (!isOwner) return reply('Só o Italu pode fazer isso')
					anu = await nito.chats.all()
					nito.setMaxListeners(25)
					for (let _ of anu) {
						nito.deleteChat(_.jid)
					}
					reply('todos os chats foram deletados :)')
					break

//--menaikan jabatan
      case 'promover':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						pro = 'Berhasil Promote\n'
						for (let _ of mentioned) {
							pro += `@${_.split('@')[0]}\n`
						}
						mentions(from, mentioned, true)
						nito.groupRemove(from, mentioned)
					} else {
						mentions(`O usuário: @${mentioned[0].split('@')[0]} foi promovido para o cargo de administrador do grupo`, mentioned, true)
						nito.groupMakeAdmin(from, mentioned)
					}
					break

  //ganti nama grup
  case 'setname':
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return reply(mess.only.admin)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
idgrup = `${from.split("@s.whatsapp.net")[0]}`;
nito.groupUpdateSubject(idgrup, `${body.slice(9)}`)
nito.sendMessage(from, 'nome do grupo alterado', text, {
  quoted: mek
})
break

  //ganti desk
  case 'setdesk':
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return reply(mess.only.admin)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
nito.groupUpdateDescription(from, `${body.slice(9)}`)
nito.sendMessage(from, 'descrição do grupo alterada', text, {
  quoted: mek
})
break

//--menurunkan jabatan
				case 'rebaixar':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						reb = 'Berhasil Demote\n'
						for (let _ of mentioned) {
							reb += `@${_.split('@')[0]}\n`
						}
						mentions(reb, mentioned, true)
						nito.groupRemove(from, mentioned)
					} else {
						mentions(`O usuário @${mentioned[0].split('@')[0]} foi rebaixado para membro comum`, mentioned, true)
						nito.groupDemoteAdmin(from, mentioned)
					}
					break

//--list admin grup
				case 'listadmins':
				  case 'listadmin':
				    case 'adminlist':
					if (!isGroup) return reply(mess.only.group)
					adl = `Lista de administradores do grupo: ${groupMetadata.subject}\nTotal: ${groupAdmins.length}\n\n`
					no = 0
					for (let admon of groupAdmins) {
						no += 1
						adl += `[${no.toString()}] @${admon.split('@')[0]}\n`
					}
					mentions(adl, groupAdmins, true)
					break

//--ganti pp bot
case 'setppbot':
  nito.updatePresence(from, Presence.composing)
  if (!isOwner) return reply(mess.only.ownerB)
  const botpp = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contxtInfo: mek
  const cuk = await nito.downloadAndSaveMediaMessage(botpp)
  await nito.updateProfilePicture(botNumber, cuk)
  reply('Obrigado pela nova foto de perfil')
  break

//event
/*case 'event':
  if (!isGroup) return reply(mess.only.group)
  if (!isOwner) return reply(mess.only.ownerB)
  if (args.length < 1) return reply('ketik 1 untuk mengaktifkan')
  if (Number(args[0]) === 1) {
if (isEventon) return reply('*SUDAH AKTIF* !!!')
event.push(from)
fs.writeFileSync('./datauser/event.json', JSON.stringify(event))
reply('*☉]* Mengaktifkan *EVENT* di group ini*')
  } else if (Number(args[0]) === 0) {
event.splice(from, 1)
fs.writeFileSync('./datauser/event.json', JSON.stringify(event))
reply('*☉* Menonaktifkan *EVENT* di group ini*')
  } else {
reply(ind.satukos())
  }
  break
*/
//--Mengambil link grup
    case 'linkgroup':
    case 'linkgc':
        if (!isGroup) return reply(mess.only.group)
        if (!isGroupAdmins) return reply(mess.only.admin)
        if (!isBotGroupAdmins) return reply(mess.only.Badmin)
        linkgc = await nito.groupInviteCode(from)
        reply('Link do grupo: https://chat.whatsapp.com/'+linkgc)
                    break

//--Mengeluarkan bot
      case 'leave':
      if (!isGroup) return reply(mess.only.group)
      if (isGroupAdmins || isOwner) {
      nito.groupLeave(from)
                    } else {
      reply(mess.only.admin)
                    }
                    break
case 'hidetag':
                nito.updatePresence(from, Presence.composing) 
                if (!isOwner) return reply(mess.only.ownerB)
                if (!isGroup) return reply(mess.only.group)
                htg = body.slice(9)
                group = await nito.groupMetadata(from);
                member = group['participants']
                jids = [];
                member.map( async adm => {
                jids.push(adm.id.replace('c.us', 's.whatsapp.net'));
                 })
                 options = {
                 text: htg,
                contextInfo: {mentionedJid: jids},
                quoted: mek
                }
              await nito.sendMessage(from, options, text)
               break
             case 'total':
                 total = `Total: ${_registered.length}`
                 reply(total)
                 break 
    case 'xac':
                 total = `Total: ${uang.length}`
                 reply(total)
                 break
//--Convert stiker to image
				case 'toimg':
				    nito.updatePresence(from, Presence.composing)
                                    if (!isRegister) return reply(mess.only.registrarB)
					if (!isQuotedSticker) return reply('Você precisa marcar um sticker não animado para isso')
					reply(mess.wait)
					tomg = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					medtmg = await nito.downloadAndSaveMediaMessage(tomg)
					ran = getRandom('.png')
					exec(`ffmpeg -i ${medtmg} ${ran}`, (err) => {
						fs.unlinkSync(medtmg)
						if (err) return reply('❌falha ao converter sticker em imagem❌')
						buffer = fs.readFileSync(ran)
						nito.sendMessage(from, buffer, image, {quoted: mek, caption: 'conversão sucedida'})
						fs.unlinkSync(ran)
					})
					break


//--arti mimpi
  case 'artimimpi':
aruga = body.slice(11)
if (!isRegister) return reply(mess.only.daftarB)
if (args.length < 1) return reply(`Mimpi apa ?\nContoh: ${prefix}artimimpi ular`)
try {
anu = await fetchJson(`https://videfikri.com/api/primbon/artimimpi/?mimpi=${aruga}`, {
  method: 'get'
})
reply(anu.result.artimimpi)

} catch {
  reply('Sepertinya fitur sedang eror')
}
break




//--Verifkasi
case 'registrar':
case 'daftar':
case 'register':
case 'registra':
if (isRegister) return reply('Você já se registrou')
const namaUser = `${pushname}`
const umurUser = `${sender}`
const serialUser = createSerial(20)
try {
ppimg = await nito.getProfilePicture(`${sender.split('@')[0]}@c.us`)
  } catch {
ppimg = 'https://i.ibb.co/rxPtZS8/foto.jpg'
  }        
  addRegisteredUser(sender, namaUser, umurUser, time, serialUser)
  addATM(sender)
  addLevelingLevel(sender, 1)
  addLevelingXp(sender, 1000)
  hsil = 
`    〘 Registrado com sucesso 〙
  Código: ${serialUser}
╔══════════════════
╠≽️ Nome: ${namaUser}
╠≽️ Perfil: @${sender.split("@")[0]}
╠≽️ Número: ${sender.split("@")[0]}
╚══════════════════
você se registrou, digite ${prefix}menu para listar meus comandos`
img = await getBuffer (ppimg)
nito.sendMessage(from, img, image, {quoted: mek, caption: hsil, contextInfo: {mentionedJid: [sender]}})
break

case 'teste':
if (!isRegister) return reply(mess.only.daftarB)
 pok = fs.readFileSync('./database/cara/coroa.webp');
 tes = fs.readFileSync('./teste/a1.jpg');
nito.sendMessage(from, tes, image, {quoted: mek})
nito.sendMessage(from, pok, sticker, {quoted: mek})
nito.sendImage(from, tes, image)
break


//--grup semua peserta
case 'fecharg':
  nito.updatePresence(from, Presence.composing)
  if (!isGroup) return reply(mess.only.group)
  if (!isGroupAdmins) return reply(mess.only.admin)
  if (!isBotGroupAdmins) return reply(mess.only.Badmin)
  var nomor = mek.participant
  const close = {
text: `Grupo fechado por: @${nomor.split("@s.whatsapp.net")[0]}`,
contextInfo: {
  mentionedJid: [nomor]
}
  }
  nito.groupSettingChange (from, GroupSettingChange.messageSend, true);
  reply(close)
  break

//--grup hanya admin
case 'openg':
  case 'abrirg':
nito.updatePresence(from, Presence.composing)
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return reply(mess.only.admin)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
open = {
  text: `Grupo aberto por: @${sender.split("@")[0]}`,
  contextInfo: {
mentionedJid: [sender]
  }
}
nito.groupSettingChange (from, GroupSettingChange.messageSend, false)
nito.sendMessage(from, open, text, {
  quoted: mek
})
break

//---mengahapus pesan bot
case 'delete':
  case 'del':
case 'apagar':
if (!isGroup)return reply(mess.only.group)
if (!isRegister) return reply(mess.only.daftarB)
if (!isGroupAdmins)return reply(mess.only.admin)
try {
nito.deleteMessage(from, {
  id: mek.message.extendedTextMessage.contextInfo.stanzaId, remoteJid: from, fromMe: true
})
} catch {
  reply('Só é possível deletar mensagens minhas')
}
break

//--ganteng cekkkk
  case 'gantengcek':
if (args.length < 1) return reply('Masukan nama target')
ganteng = body.slice(12)
const gan = ['10',
  '30',
  '20',
  '40',
  '50',
  '60',
  '70',
  '62',
  '74',
  '83',
  '97',
  '100',
  '29',
  '94',
  '75',
  '82',
  '41',
  '39']
const teng = gan[Math.floor(Math.random() * gan.length)]
nito.sendMessage(from, 'Gantengcek : '+ganteng+'\n\nJawaban : '+ teng+'%', text, {
  quoted: mek
})
break

//--Cantik cekk
  case 'cantikcek':
if (args.length < 1) return reply('Masukan nama target')
cantik = body.slice(12)
const can = ['10',
  '30',
  '20',
  '40',
  '50',
  '60',
  '70',
  '62',
  '74',
  '83',
  '97',
  '100',
  '29',
  '94',
  '75',
  '82',
  '41',
  '39']
const tik = can[Math.floor(Math.random() * can.length)]
nito.sendMessage(from, 'Cantikcek *'+cantik+'*\n\nJawaban : '+ tik+'%', text, {
  quoted: mek
})
break



				case 'welcome':
					if (!isGroup) return reply(mess.only.group)
                    if (!isRegister) return reply(mess.only.registrarB)
					if (!isGroupAdmins) return reply(mess.only.Badmin)
					if (args.length < 1) return reply('use =welcome 1 para ativar')
					if (Number(args[0]) === 1) {
				    if (isWelkom) return reply('já está ativado')
						welkom.push(from)
						fs.writeFileSync('./database/json/welkom.json', JSON.stringify(welkom))
						reply('O recurso bem-vindo foi ativado')
					} else if (Number(args[0]) === 0) {
						welkom.splice(from, disable)
						fs.writeFileSync('./database/json/welkom.json', JSON.stringify(welkom))
						reply('O recurso bem-vindo foi desativado')
					} else {
						reply(`digite ${prefix}welcome 1 para ativar, e 0 para desativar o recurso`)
					}
                         break
				case 'clone':
					if (!isGroup) return reply(mess.only.group)
					if (!isOwner) return reply(mess.only.ownerB)
					if (args.length < 1) return reply('Mencione quem devo roubar a foto de perfil')
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag cvk')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					let { jid, id, notify } = groupMembers.find(x => x.jid === mentioned)
					try {
						pp = await nito.getProfilePicture(id)
						buffer = await getBuffer(pp)
						nito.updateProfilePicture(botNumber, buffer)
						mentions(`Roubei a foto de perfil de: @${id.split('@')[0]}`, [jid], true)
					} catch (e) {
						reply('ocorreu um erro')
					}
					break
			
//mini games, rate, random

case 'conta':
if (!isRegister) return reply(mess.only.registrarB)
con = ["+","×","÷","-"]
ty = con[Math.floor(Math.random() * con.length)]
number1 = `${Math.floor(Math.random() * 100)}`
number2 = `${Math.floor(Math.random() * 100)}`
conta = `Quanto é ${number1} ${ty} ${number2}?`
reply(conta)
break

case 'dado':
if (!isRegister) return reply(mess.only.registrarB)
const dadus = ["⚀","⚁","⚂","⚃","⚄","⚅"]
dadu = dadus[Math.floor(Math.random() * dadus.length)]
dador = fs.readFileSync('./database/dados/'+dadu+'.webp')
nito.sendMessage(from, dador, sticker, {quoted: mek})
break

case 'caracoroa':
if (!isRegister) return reply(mess.only.registrarB)
			const cara = fs.readFileSync('./database/cara/cara.webp');
			const coroa = fs.readFileSync('./database/cara/coroa.webp');
			cararo = ["cara", "coroa"]
			fej = cararo[Math.floor(Math.random() * cararo.length)]
			gg = fej
reply(`você conseguiu: ${fej}`)
			cararoa = fs.readFileSync('./database/cara/'+fej+'.webp')
            nito.sendMessage(from, cararoa, sticker, {quoted: mek})
break
case 'dad':
cararoa = fs.readFileSync('./database/teste.webp')
nito.sendMessage(from, cararoa, sticker, {quoted: mek})

break
case "ppt":
if (!isRegister) return reply(mess.only.registrarB)
if(args.length < 1) return reply(mess.tterro)
/*if (!q.includes("✊pedra")) return reply(mess.tterro)
if (!q.includes("🤚papel")) return reply(mess.tterro)
if (!q.includes("✌tesoura")) return reply(mess.tterro)*/
                pptt = `A vitória é de ${pushname}`
                pptt2 = `A vitória é de ${NamaBot}`
                pptt3 = `Empate`
                ppt = ["✊pedra","🤚papel","✌tesoura"]
                ppta = body.slice(4)
                pptb = ppt[Math.floor(Math.random() * ppt.length)]             
                vencedor = `definição de vitória indisponível no momento`
                pptf = `O ${NamaBot} escolheu: ${pptb}\n\nVocê escolheu: ${ppta}\n\nA vitória é de.... ${vencedor}`
                nito.sendMessage(from, pptf, text, {quoted: mek})
                break

/*const bot = pptb
if (bot = ✊pedra)*/


                case "pptt":
                if(args.length < 1) return nito.reply(mess.tterro)
                pptt = `A vitória do do(a) ${pushname}`
                pptt2 = `A vitória do do(a) ${botName}`
                pptt3 = `Empate`
                ppt = ["âœŠpedra","âœ‹papel","âœŒtesoura"]
                ppta = body.slice(4)
                pptb = ppt[Math.floor(Math.random() * ppt.length)]
                
                vencedor = `definição de vitória indisponível no momento`
                pptf = `O ${botName} escolheu: ${pptb}\n\nVocÃª escolheu: ${ppta}\n\nA vitória do de.... ${vencedor}`
                nito.sendMessage(from, pptf, text, {quoted: mek})
                break
                
        case 'morte':
		case 'death':
if (!isRegister) return reply(mess.only.registrarB)
		    idde = ["30","76","90","72","83","73","83","74","92","100","94","48","37","53","63"]
            idade = idde[Math.floor(Math.random() * (idde.length))]
			morte = `Pessoas com este nome: ${pushname} \nTendem a morrer aos ${idade} anos de idade.`
			reply(morte)
			break
			
case 'sn':
if (!isRegister) return reply(mess.only.registrarB)
            const sn = ['sim', 'não']
                     gosto = body.slice(3)
                     if (args.length < 1) return nito.sendMessage(from, `Você deve fazer uma pergunta...\nExemplo: ${prefix}sn O Italu é um baiano preguiçoso?`, text, {quoted: mek})
                     const jawab = sn[Math.floor(Math.random() * (sn.length))]
                     hasil = `${gosto}\n\nAcredito que... ${jawab}`
                     reply(hasil)
                     break
                     
case 'gadometro':
		case 'gado':
if (!isRegister) return reply(mess.only.registrarB)
			var chifre = ["ultra extreme gado", "Gado-Master", "Gado-Rei", "Gado", "Escravo-ceta", "Escravo-ceta Maximo", "Gacorno?", "Jogador De Forno Livre<3", "Mestre Do Frifai<3<3", "Gado-Manso", "Gado-Conformado", "Gado-Incubado", "Gado Deus", "Mestre dos Gados", "Topa tudo por buceta", "Gado Comum", "Mini Gadinho", "Gado Iniciante", "Gado Basico", "Gado Intermediario", "Gado Avançado", "Gado Profisional", "Gado Mestre", "Gado Chifrudo", "Corno Conformado", "Corno HiperChifrudo", "Chifrudo Deus", "Mestre dos Chifrudos"]
			var gado = chifre[Math.floor(Math.random() * chifre.length)]
			gadop = `${Math.floor(Math.random() * 100)}`
			hisil = `Você é:\n\n${gado}`
			reply(hisil)
			break
			
case 'oculto':
            if (!isGroup) return reply(mess.only.group)
            
            const mem = eur[Math.floor(Math.random() * eur.length)]
    	    var xvid = ["Negoes branquelos e feministas", `${pushname} se depilando na banheira`, `${pushname} comendo meu cuzinho`, `${pushname} quer me comer o que fazer?`, "lolis nuas e safadas", "Ursinhos Mansos Peludos e excitados", "mae do adm cozida na pressao", "Buceta de 500 cm inflavel da boneca chinesa lolita company", "corno manso batendo uma pra mim com meu rosto na webcam", "tigresa vip da buceta de mel", "belle delphine dando o cuzinho no barzinho da esquina", "fazendo anal no negao", "africanos nus e chupando pau", "anal africano", "comendo a minha tia", "lgbts fazendo ahegao", "adm gostoso tirando a roupa", "gays puxando o intestino pra fora", "Gore de porno de cachorro", "anoes baixinhos do pau grandao", "AnÃµes Gays Dotados Peludos", "anÃµes gays dotados penetradores de botas", "Ursinhos Mansos Peludos", "Jailson Mendes", "Vendo meu Amigo Comer a Esposa", "Golden Shower"]
            const surpresa2 = xvid[Math.floor(Math.random() * xvid.length)]
            xvidd = `EQUIPE ❌VIDEOS\n\nCaro usuário @${mem.jid.split('@')[0]}...\n\nSou da administração do Xvideos e nós percebemos que você não entrou em sua conta por mais de 2 semanas e decidimos checar pra saber se está tudo OK com o(a) nosso(a) usuário(a) mais ativo(a).\n\nDesde a última vez que você visitou nosso site, você procurou mais de centenas de vezes por ${surpresa2} (acreditamos ser sua favorita), viemos dizer que elas foram adicionadas e temos certeza que você irá gostar bastante.\nEsperamos você lá!\n\nPara o nosso usuário(a) favorito(a), com carinho, Equipe Xvideos.`
            reply(xvidd)
            break
            
            case 'detector' :
            if (!isGroupMsg) return reply('Apenas grupos!', {quoted: mek})
			return reply(from, 'Calculando foto dos participantes do grupo...', {quoted: mek})
             sleep(3000)
            const eu = (pushname)
            const gostosa = [Math.floor(Math.random() * length)]
			console.log(gostosa.id)
             nito.sendTextWithMentions(from, `*`)
             sleep(2000)
            break
            




  todos += `┃ @${mem.jid.split('@')[0]}\n`
  
mentions('╭╾╼◐⚋ ༒ᴍᴇɴᴄɪᴏɴᴀʀ ᴛᴏᴅᴏs ༒⚋◑╾╼╮\n┠⊷'+todos+'╰╾╼◐⚋⚋   ༒Ⓘ𝐓α𝕃ᑌ🧐༒  ⚋⚋◑╾╼╯', members_id, true)
break


case 'ship':
if (!isGroup) return reply(mess.only.group)
if (!isRegister) return reply(mess.only.daftarB)
ag = groupMetadata.participants(from)
const mem2 = ag[Math.floor(Math.random() * (ag.length))]
const mem1 = ag[Math.floor(Math.random() * (ag.length))]
casal = `@${mem1.jid.split('@')[0]}  teste @${mem2.jid.split('@')[0]}`
nito.sendMessage(from, casal, text, {quoted: mek, contextInfo: {"mentionedJid": [mem1, mem2]}})
break
			
case 'slot':
if (!isRegister) return reply(mess.only.registrarB)
		 const somtoy = sotoy[Math.floor(Math.random() * (sotoy.length))]	
          const somtoy2 = sotoy2[Math.floor(Math.random() * (sotoy2.length))]	
          const somtoy3 = sotoy3[Math.floor(Math.random() * (sotoy3.length))]	
					nito.sendMessage(from, slot(somtoy, somtoy2, somtoy3), text, {quoted: mek})
					break
			
					
case 'chance':
if (!isRegister) return reply(mess.only.registrarB)
              nito.updatePresence(from, Presence.composing) 
                var avb = body.slice(7)
                if (args.length < 1) return nito.sendMessage(from, `Você precisa digitar da forma correta\nExemplo: ${prefix}chance do Italu ser um trouxa`, text, {quoted: mek})
                random = `${Math.floor(Math.random() * 100)}`
               hasil = `A chance ${body.slice(7)}\n\né de... ${random}%`
             nito.sendMessage(from, hasil, text, {quoted: mek, contextInfo: {mentionedJid: [sender]}})
                break
     
case 'dadog':
if (!isRegister) return reply(mess.only.daftarB)
nito.updatePresence(from, Presence.composing)
reply(mess.wait)
const dadusg = ["https://i.ibb.co/njdfrHT/jogodedados-128px-1.gif","https://i.ibb.co/Bw42zpY/jogodedados-128px-2.gif","https://i.ibb.co/BBcyPp2/jogodedados-128px-3.gif","https://i.ibb.co/YhhDbX5/jogodedados-128px-4.gif","https://i.ibb.co/9g8ns1b/jogodedados-128px-5.gif","https://i.ibb.co/qFTd1K1/jogodedados-128px-6.gif"]
try {
const dadugg = dadusg[Math.floor(Math.random() * (dadusg.length))]	
pok = await getBuffer(dadugg)
nito.sendMessage(from, pok, image, {quoted: mek})
} catch {
  reply(mess.ferr)
}
break
      
case 'pau':
if (!isRegister) return reply(mess.only.registrarB)
random = `${Math.floor(Math.random() * 35)}`
const tamanho = random
//var (isNaN(tamanho))
if (tamanho < 13 ) {
pp = 'só a fimose'
} else if (tamanho == 13 ) {
pp = 'passou da média😳'
} else if (tamanho == 14 ) {
pp = 'passou da média😳'
} else if (tamanho == 15 ) {
pp = 'eita, vai pegar manga?'
} else if (tamanho == 16 ) {
pp = 'eita, vai pegar manga?'
} else if (tamanho == 17 ) {
pp = 'calma man, a mina não é um poço😳'
} else if (tamanho == 18 ) {
pp = 'calma man, a mina não é um poço😳'
} else if (tamanho == 19 ) {
pp = 'calma man, a mina não é um poço😳'
} else if (tamanho == 20 ) {
pp = 'você tem um poste no meio das pernas'
} else if (tamanho == 21 ) {
pp = 'você tem um poste no meio das pernas'
} else if (tamanho == 22 ) {
pp = 'você tem um poste no meio das pernas'
} else if (tamanho == 23 ) {
pp = 'você tem um poste no meio das pernas'
} else if (tamanho == 24 ) {
pp = 'você tem um poste no meio das pernas'
} else if (tamanho > 25 ) {
pp = 'vai procurar petróleo com isso?'
}
hasil = `Seu pau tem ${random}cm ${pp}`
reply(hasil)
break
   
                case 'gay':
if (!isRegister) return reply(mess.only.registrarB)
nito.updatePresence(from, Presence.composing) 
random = `${Math.floor(Math.random() * 100)}`
boiola = random
if (boiola < 20 ) {
bo = 'hmm... você é hetero😔'
} else if (boiola == 21 ) {
bo = '+/- boiola'
} else if (boiola == 23 ) {
bo = '+/- boiola'
} else if (boiola == 24 ) {
bo = '+/- boiola'
} else if (boiola == 25 ) {
bo = '+/- boiola'
} else if (boiola == 26 ) {
bo = '+/- boiola'
} else if (boiola == 27 ) {
bo = '+/- boiola'
} else if (boiola == 28  ) {
bo = '+/- boiola'
} else if (boiola == 29 ) {
bo = '+/- boiola'
} else if (boiola == 30 ) {
bo = '+/- boiola'
} else if (boiola == 31 ) {
bo = 'tenho minha desconfiança...😑'
} else if (boiola == 32 ) {
bo = 'tenho minha desconfiança...😑'
} else if (boiola == 33 ) {
bo = 'tenho minha desconfiança...😑'
} else if (boiola == 34 ) {
bo = 'tenho minha desconfiança...😑'
} else if (boiola == 35 ) {
bo = 'tenho minha desconfiança...😑'
} else if (boiola == 36 ) {
bo = 'tenho minha desconfiança...😑'
} else if (boiola == 37 ) {
bo = 'tenho minha desconfiança...😑'
} else if (boiola == 38 ) {
bo = 'tenho minha desconfiança...😑'
} else if (boiola == 39 ) {
bo = 'tenho minha desconfiança...😑'
} else if (boiola == 40 ) {
bo = 'tenho minha desconfiança...😑'
} else if (boiola == 41 ) {
bo = 'você é né?😏'
} else if (boiola == 42 ) {
bo = 'você é né?😏'
} else if (boiola == 43 ) {
bo = 'você é né?😏'
} else if (boiola == 44 ) {
bo = 'você é né?😏'
} else if (boiola == 45 ) {
bo = 'você é né?😏'
} else if (boiola == 46 ) {
bo = 'você é né?😏'
} else if (boiola == 47 ) {
bo = 'você é né?😏'
} else if (boiola == 48 ) {
bo = 'você é né?😏'
} else if (boiola == 49 ) {
bo = 'você é né?😏'
} else if (boiola == 50 ) {
bo = 'você é ou não?🧐'
} else if (boiola > 51) {
bo = 'você é gay🙈'
}
hasil = `Você é ${random}% gay\n\n${bo}`
reply(hasil)
break


//mini games, rate, random
//COMANDOS NSFW
case 'blowjob':
					

				    try{
						if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
                                                if (!isRegister) return reply(mess.only.registrarB)
						res =  fetchJson(`https://tobz-api.herokuapp.com/api/nsfwblowjob?apikey=BotWeA`, {method: 'get'})
						buffer =  getBuffer(res.result)
						nito.sendMessage(from, buffer, image, {quoted: mek, caption: 'glub glub'})
					} catch (e) {
						console.log(`erro :`, color(e,'red'))
						reply('❌ocorreu um erro❌')
					}
					break

case 'gasm':
						

						try {
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
							res =  fetchJson(`https://nekos.life/api/v2/img/gasm`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: 'sla que pohessakkkk'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break
						                case 'kemonomimi':
						reply(mess.wait)

						try {
							res =  fetchJson(`https://nekos.life/api/v2/img/kemonomimi`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: 'nii...'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break

case 'eroyuri':
                        

						try {
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
							res =  fetchJson(`https://nekos.life/api/v2/img/eroyuri`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: 'âœ‚ï¸âœ‚ï¸'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break
						                case 'feet':
						

						try {
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
							res =  fetchJson(`https://nekos.life/api/v2/img/feet`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: 'pezinho para vc, otaku punheteirokkkk.'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break

case 'nsfwavatar':
						

						try {
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
							res =  fetchJson(`https://nekos.life/api/v2/img/nsfw_avatar`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: 'avatar nsfw para perfil'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break
                                        case 'cuddle':
                        reply(mess.wait)

						try {
							res =  fetchJson(`https://nekos.life/api/v2/img/cuddle`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: '.'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break
						                case 'hug':
						reply(mess.wait)

						try {
							res =  fetchJson(`https://nekos.life/api/v2/img/hug`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: '.'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break

case 'ero':
						

						try {
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
							res =  fetchJson(`https://nekos.life/api/v2/img/ero`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: '.'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break
						                case 'solo':
						

						try {
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
							res =  fetchJson(`https://nekos.life/api/v2/img/solo`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: '.'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break

case 'solog':
						

						try {
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
							res =  fetchJson(`https://nekos.life/api/v2/img/solog`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: '.'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break
						                case 'lewd':
						

						try {
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
							res =  fetchJson(`https://nekos.life/api/v2/img/lewd`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: '.'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break

case 'foxg':
						reply(mess.wait)

						try {
							res =  fetchJson(`https://nekos.life/api/v2/img/fox_girl`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: '.'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break
						                case 'lewdkemo':
						

						try {
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
							res =  fetchJson(`https://nekos.life/api/v2/img/lewdkemo`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: '.'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break

case 'smug':
						reply(mess.wait)

						try {
							res =  fetchJson(`https://nekos.life/api/v2/img/smug`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: '.'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break
						                case 'anal':
						

						try {
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
							res =  fetchJson(`https://nekos.life/api/v2/img/anal`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: '.'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break

case 'hololewd':
						try {
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
							res =  fetchJson(`https://nekos.life/api/v2/img/hololewd`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: '.'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break

case 'hentai2':
						

						try {
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
							res =  fetchJson(`https://nekos.life/api/v2/img/hentai`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: '.'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break
						                case 'les':
						reply(mess.wait)

						try {
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
							res =  fetchJson(`https://nekos.life/api/v2/img/les`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: '.'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break
						                case 'holo':
						reply(mess.wait)

						try {
							res =  fetchJson(`https://nekos.life/api/v2/img/holo`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: '.'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break
case 'erofeet':
						

						try {
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
							res =  fetchJson(`https://nekos.life/api/v2/img/erofeet`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: '.'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break
						
						
						
						                case 'tickle':
						reply(mess.wait)

						try {
							res =  fetchJson(`https://nekos.life/api/v2/img/tickle`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: 'nii...'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break
						                case 'femdom':
						

						try {
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo??')
reply(mess.waitsfw)
							res =  fetchJson(`https://nekos.life/api/v2/img/femdom`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: '.'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break

case 'sneko':
					

						try {
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
							res =  fetchJson(`https://nekos.life/api/v2/img/nsfw_neko_gif`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: 'nyan...'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break
						                case 'cum':
						

						try {
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
							res =  fetchJson(`https://nekos.life/api/v2/img/cum`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: 'doce de loli?'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break
case 'yuri':
						

						try {
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
							res =  fetchJson(`https://nekos.life/api/v2/img/yuri`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: 'altas tesouras âœ‚ï¸âœ‚ï¸'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break
						
						
                            case 'wallpaper':
            

            
						try {
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
							res =  fetchJson(`https://nekos.life/api/v2/img/wallpaper`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: '.'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break
case'hentaig':

						if (!isRegister) return reply(mess.only.registrarB)
if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
					cry = getRandom('.gif')
					rano = getRandom('.webp')
					kissgif =  fetchJson(`https://nekos.life/api/v2/img/Random_hentai_gif`, {method: 'get'})
					reply (mess.wait)
					exec(`wget ${kissgif.result} -O ${cry} && ffmpeg -i ${cry} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
						fs.unlinkSync(cry)
						buffer = fs.readFileSync(rano)
						nito.sendMessage(from, buffer, sticker, {quoted: mek})
						fs.unlinkSync(rano)
					})
					 limitAdd(sender) 
					break 
						
						                case 'pussy':
						

						try {
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
							res =  fetchJson(`https://nekos.life/api/v2/img/pussy_jpg`, {method: 'get'})
							buffer =  getBuffer(res.url)
							nito.sendMessage(from, buffer, image, {quoted: mek, caption: '.'})
						} catch (e) {
							console.log(`Error :`, color(e,'red'))
							reply('❌ocorreu um erro❌')
						}
						break
case'futa':
							if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
							res =  fetchJson(`https://nekos.life/api/v2/img/futanari`, {method: 'get'})
						n = JSON.parse(JSON.stringify(res));
nimek = n[Math.floor(Math.random() * n.length)];
pok = await getBuffer(nimek)
nito.sendMessage(from, pok, image, {quoted: mek, caption: 'Mulher sem pinto Ã© igual a anjo sem asasðŸ˜“'})
						break
/*                case 'neko':
const nekos = ["https://nekos.life/api/v2/img/erok","https://nekos.life/api/v2/img/erokemo","https://nekos.life/api/v2/img/lewdk",*/
case'boobs':
if (!isNsfw) return reply('🚫funções NSFW desativadas nesse grupo🚫')
reply(mess.waitsfw)
res = fetchJson(`https://nekos.life/api/v2/img/pussy_jpg`)
ffg = (res.url)
ggf = getBuffer (ffg)
nito.sendMessage(from, ggf, image, {quoted: mek})
break

case 'baka':
await neko.sfw.neko(async (err, res) => {
buffer = await getBuffer(res.url)
nito.sendMessage(from, buffer, image, {quoted: mek, caption: 'Ingat! Citai Lolimu'})
})
break

case 'lolil':
					loli.getSFWLoli(async (err, res) => {
						if (err) return reply('❌ *ERROR* ❌')
						buffer = await getBuffer(res.url)
						nito.sendMessage(from, buffer, image, {quoted: mek, caption: 'Ingat! Citai Lolimu'})
					})
					break

				default:
				if (body.startsWith(`${prefix}${command}`)) {
                hsl = `        ────────────────\nOi @${sender.split("@")[0]}!!\nO comando: ${prefix}${command} não existe\n\nTem certeza que digitou corretamente?🧙‍♂️\nUse ${prefix}Menu para listar meus comandos\n        ────────────────`
  nito.sendMessage(from, hsl, text, {quoted: mek, contextInfo: {mentionedJid: [sender]}})
				}
                           if (isGroup && isSimi && budy != undefined) {
						console.log(budy)
						muehe = await simih(budy)
						console.log(muehe)
						reply(muehe)
					} else {
						return //console.log(color('[WARN]','red'), 'Unregistered Command from', color(sender.split('@')[0]))
					}
                           }
		} catch (e) {
			console.log('Error : %s', color(e, 'green'))
		}
	})
}
starts()
